-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 24, 2016 at 01:29 PM
-- Server version: 5.5.52-MariaDB-1ubuntu0.14.04.1
-- PHP Version: 5.6.23-1+deprecated+dontuse+deb.sury.org~trusty+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blazedeskcrm_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_aauth_perms`
--

CREATE TABLE IF NOT EXISTS `blzdsk_aauth_perms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `defination` text,
  PRIMARY KEY (`id`),
  KEY `id_index` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `blzdsk_aauth_perms`
--

INSERT INTO `blzdsk_aauth_perms` (`id`, `name`, `defination`) VALUES
(1, 'view', 'User Can Access View feature.!!'),
(2, 'add', 'User Can Access add feature.!!'),
(3, 'edit', 'User Can Access Edit feature.!!'),
(4, 'delete', 'User Can Access Delete feature.!!');

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_aauth_perm_to_group`
--

CREATE TABLE IF NOT EXISTS `blzdsk_aauth_perm_to_group` (
  `perm_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `component_name` varchar(100) NOT NULL,
  KEY `perm_id_role_id_index` (`perm_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blzdsk_aauth_perm_to_group`
--

INSERT INTO `blzdsk_aauth_perm_to_group` (`perm_id`, `role_id`, `module_id`, `component_name`) VALUES
(1, 39, 8, 'CRM'),
(2, 39, 8, 'CRM'),
(3, 39, 8, 'CRM'),
(4, 39, 8, 'CRM'),
(1, 39, 9, 'CRM'),
(2, 39, 9, 'CRM'),
(3, 39, 9, 'CRM'),
(4, 39, 9, 'CRM'),
(1, 39, 11, 'CRM'),
(2, 39, 11, 'CRM'),
(3, 39, 11, 'CRM'),
(4, 39, 11, 'CRM'),
(1, 39, 13, 'CRM'),
(2, 39, 13, 'CRM'),
(3, 39, 13, 'CRM'),
(4, 39, 13, 'CRM'),
(1, 39, 14, 'CRM'),
(2, 39, 14, 'CRM'),
(3, 39, 14, 'CRM'),
(4, 39, 14, 'CRM'),
(1, 39, 15, 'CRM'),
(2, 39, 15, 'CRM'),
(3, 39, 15, 'CRM'),
(4, 39, 15, 'CRM'),
(1, 39, 18, 'CRM'),
(2, 39, 18, 'CRM'),
(3, 39, 18, 'CRM'),
(4, 39, 18, 'CRM'),
(1, 39, 19, 'CRM'),
(2, 39, 19, 'CRM'),
(3, 39, 19, 'CRM'),
(4, 39, 19, 'CRM'),
(1, 39, 21, 'CRM'),
(2, 39, 21, 'CRM'),
(3, 39, 21, 'CRM'),
(4, 39, 21, 'CRM'),
(1, 39, 23, 'CRM'),
(2, 39, 23, 'CRM'),
(3, 39, 23, 'CRM'),
(4, 39, 23, 'CRM'),
(1, 39, 33, 'CRM'),
(2, 39, 33, 'CRM'),
(3, 39, 33, 'CRM'),
(4, 39, 33, 'CRM'),
(1, 39, 34, 'CRM'),
(2, 39, 34, 'CRM'),
(3, 39, 34, 'CRM'),
(4, 39, 34, 'CRM'),
(1, 39, 35, 'CRM'),
(2, 39, 35, 'CRM'),
(3, 39, 35, 'CRM'),
(4, 39, 35, 'CRM'),
(1, 39, 38, 'CRM'),
(2, 39, 38, 'CRM'),
(3, 39, 38, 'CRM'),
(4, 39, 38, 'CRM'),
(1, 39, 43, 'CRM'),
(2, 39, 43, 'CRM'),
(3, 39, 43, 'CRM'),
(4, 39, 43, 'CRM'),
(1, 39, 44, 'CRM'),
(2, 39, 44, 'CRM'),
(3, 39, 44, 'CRM'),
(4, 39, 44, 'CRM'),
(1, 39, 45, 'CRM'),
(2, 39, 45, 'CRM'),
(3, 39, 45, 'CRM'),
(4, 39, 45, 'CRM'),
(1, 39, 47, 'CRM'),
(2, 39, 47, 'CRM'),
(3, 39, 47, 'CRM'),
(4, 39, 47, 'CRM'),
(1, 39, 55, 'Support'),
(2, 39, 55, 'Support'),
(3, 39, 55, 'Support'),
(4, 39, 55, 'Support'),
(1, 39, 56, 'Support'),
(2, 39, 56, 'Support'),
(3, 39, 56, 'Support'),
(4, 39, 56, 'Support'),
(1, 39, 61, 'CRM'),
(2, 39, 61, 'CRM'),
(3, 39, 61, 'CRM'),
(4, 39, 61, 'CRM'),
(1, 39, 65, 'CRM'),
(2, 39, 65, 'CRM'),
(3, 39, 65, 'CRM'),
(4, 39, 65, 'CRM'),
(1, 39, 71, 'CRM'),
(2, 39, 71, 'CRM'),
(3, 39, 71, 'CRM'),
(4, 39, 71, 'CRM'),
(1, 39, 72, 'CRM'),
(2, 39, 72, 'CRM'),
(3, 39, 72, 'CRM'),
(4, 39, 72, 'CRM'),
(1, 39, 75, 'CRM'),
(2, 39, 75, 'CRM'),
(3, 39, 75, 'CRM'),
(4, 39, 75, 'CRM'),
(1, 39, 77, 'CRM'),
(2, 39, 77, 'CRM'),
(3, 39, 77, 'CRM'),
(4, 39, 77, 'CRM'),
(1, 39, 78, 'CRM'),
(2, 39, 78, 'CRM'),
(3, 39, 78, 'CRM'),
(4, 39, 78, 'CRM'),
(1, 39, 16, 'PM'),
(2, 39, 16, 'PM'),
(3, 39, 16, 'PM'),
(4, 39, 16, 'PM'),
(1, 39, 24, 'PM'),
(2, 39, 24, 'PM'),
(3, 39, 24, 'PM'),
(4, 39, 24, 'PM'),
(1, 39, 25, 'PM'),
(2, 39, 25, 'PM'),
(3, 39, 25, 'PM'),
(4, 39, 25, 'PM'),
(1, 39, 26, 'PM'),
(2, 39, 26, 'PM'),
(3, 39, 26, 'PM'),
(4, 39, 26, 'PM'),
(1, 39, 27, 'PM'),
(2, 39, 27, 'PM'),
(3, 39, 27, 'PM'),
(4, 39, 27, 'PM'),
(1, 39, 28, 'settings'),
(2, 39, 28, 'settings'),
(3, 39, 28, 'settings'),
(4, 39, 28, 'settings'),
(1, 39, 36, 'PM'),
(2, 39, 36, 'PM'),
(3, 39, 36, 'PM'),
(4, 39, 36, 'PM'),
(1, 39, 39, 'PM'),
(2, 39, 39, 'PM'),
(3, 39, 39, 'PM'),
(4, 39, 39, 'PM'),
(1, 39, 41, 'PM'),
(2, 39, 41, 'PM'),
(3, 39, 41, 'PM'),
(4, 39, 41, 'PM'),
(1, 39, 46, 'PM'),
(2, 39, 46, 'PM'),
(3, 39, 46, 'PM'),
(4, 39, 46, 'PM'),
(1, 39, 53, 'PM'),
(2, 39, 53, 'PM'),
(3, 39, 53, 'PM'),
(4, 39, 53, 'PM'),
(1, 39, 54, 'PM'),
(2, 39, 54, 'PM'),
(3, 39, 54, 'PM'),
(4, 39, 54, 'PM'),
(1, 39, 59, 'PM'),
(2, 39, 59, 'PM'),
(3, 39, 59, 'PM'),
(4, 39, 59, 'PM'),
(1, 39, 66, 'PM'),
(2, 39, 66, 'PM'),
(3, 39, 66, 'PM'),
(4, 39, 66, 'PM'),
(1, 39, 51, 'Support'),
(2, 39, 51, 'Support'),
(3, 39, 51, 'Support'),
(4, 39, 51, 'Support'),
(1, 39, 52, 'Support'),
(2, 39, 52, 'Support'),
(3, 39, 52, 'Support'),
(4, 39, 52, 'Support'),
(1, 39, 57, 'Support'),
(2, 39, 57, 'Support'),
(3, 39, 57, 'Support'),
(4, 39, 57, 'Support'),
(1, 39, 58, 'Support'),
(2, 39, 58, 'Support'),
(3, 39, 58, 'Support'),
(4, 39, 58, 'Support'),
(1, 39, 67, 'Support'),
(2, 39, 67, 'Support'),
(3, 39, 67, 'Support'),
(4, 39, 67, 'Support'),
(1, 39, 76, 'Support'),
(2, 39, 76, 'Support'),
(3, 39, 76, 'Support'),
(4, 39, 76, 'Support'),
(1, 39, 79, 'Support'),
(2, 39, 79, 'Support'),
(3, 39, 79, 'Support'),
(4, 39, 79, 'Support'),
(1, 39, 7, 'User'),
(2, 39, 7, 'User'),
(3, 39, 7, 'User'),
(4, 39, 7, 'User'),
(1, 39, 17, 'settings'),
(2, 39, 17, 'settings'),
(3, 39, 17, 'settings'),
(4, 39, 17, 'settings'),
(1, 39, 40, 'settings'),
(2, 39, 40, 'settings'),
(3, 39, 40, 'settings'),
(4, 39, 40, 'settings'),
(1, 39, 49, 'settings'),
(2, 39, 49, 'settings'),
(3, 39, 49, 'settings'),
(4, 39, 49, 'settings'),
(1, 39, 50, 'settings'),
(2, 39, 50, 'settings'),
(3, 39, 50, 'settings'),
(4, 39, 50, 'settings'),
(1, 39, 68, 'settings'),
(2, 39, 68, 'settings'),
(3, 39, 68, 'settings'),
(4, 39, 68, 'settings'),
(1, 39, 80, 'CRM'),
(2, 39, 80, 'CRM'),
(3, 39, 80, 'CRM'),
(4, 39, 80, 'CRM'),
(1, 39, 81, 'Support'),
(2, 39, 81, 'Support'),
(3, 39, 81, 'Support'),
(4, 39, 81, 'Support'),
(1, 39, 86, 'CRM'),
(2, 39, 86, 'CRM'),
(3, 39, 86, 'CRM'),
(4, 39, 86, 'CRM'),
(1, 39, 87, 'CRM'),
(2, 39, 87, 'CRM'),
(3, 39, 87, 'CRM'),
(4, 39, 87, 'CRM'),
(1, 39, 88, 'CRM'),
(2, 39, 88, 'CRM'),
(3, 39, 88, 'CRM'),
(4, 39, 88, 'CRM'),
(1, 39, 89, 'CRM'),
(2, 39, 89, 'CRM'),
(3, 39, 89, 'CRM'),
(4, 39, 89, 'CRM'),
(1, 39, 87, 'CRM'),
(2, 39, 87, 'CRM'),
(3, 39, 87, 'CRM'),
(4, 39, 87, 'CRM'),
(1, 39, 88, 'CRM');

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_appointment_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_appointment_master` (
  `apt_id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `apt_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `location` varchar(100) NOT NULL,
  `travel_time` time NOT NULL,
  `send_invite` tinyint(4) NOT NULL,
  `contact_id` int(11) NOT NULL COMMENT 'FK(contact_master)',
  `meeting_description` text NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_branch_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_branch_master` (
  `branch_id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_budget_campaign_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_budget_campaign_master` (
  `budget_campaign_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(100) NOT NULL,
  `campaign_auto_id` varchar(20) NOT NULL,
  `campaign_type_id` int(11) NOT NULL COMMENT 'FK(campaign_type_master)',
  `employee_id` int(11) NOT NULL COMMENT 'FK(contact_master)',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `campaign_description` longtext NOT NULL,
  `budget_requirement` tinyint(4) NOT NULL,
  `budget_ammount` float NOT NULL,
  `revenue_goal` float NOT NULL,
  `campaign_supplier` tinyint(4) NOT NULL,
  `supplier_id` int(11) NOT NULL COMMENT 'FK(supplier_master)',
  `related_product` tinyint(4) NOT NULL,
  `product_id` int(11) NOT NULL COMMENT 'FK(product_master)',
  `campaign_group_id` int(11) NOT NULL COMMENT 'FK(campaign_group_master)',
  `aditional_notes` text NOT NULL,
  `file` text NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`budget_campaign_id`),
  KEY `campaign_type_id` (`campaign_type_id`),
  KEY `employee_id` (`employee_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `product_id` (`product_id`),
  KEY `campaign_group_id` (`campaign_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_budget_campaign_product_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_budget_campaign_product_tran` (
  `budget_campaign_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_campaign_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`budget_campaign_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_budget_campaign_responsible_employee_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_budget_campaign_responsible_employee_tran` (
  `budget_campaign_responsible_employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_campaign_id` int(11) NOT NULL COMMENT 'FK(campaign)',
  `employee_id` int(11) NOT NULL COMMENT 'FK(contact)',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`budget_campaign_responsible_employee_id`),
  KEY `budget_campaign_id` (`budget_campaign_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_campaign_archive`
--

CREATE TABLE IF NOT EXISTS `blzdsk_campaign_archive` (
  `campaign_archive_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL,
  `campaign_name` varchar(100) NOT NULL,
  `campaign_auto_id` varchar(20) NOT NULL,
  `campaign_type_id` varchar(255) NOT NULL,
  `responsible_employee_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `campaign_description` longtext NOT NULL,
  `budget_requirement` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `budget_ammount` int(11) NOT NULL,
  `campaign_supplier` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `supplier_id` int(11) NOT NULL,
  `revenue_goal` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `revenue_amount` int(11) NOT NULL,
  `related_product` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `product_id` varchar(255) DEFAULT NULL,
  `campaign_group_id` int(11) NOT NULL,
  `file` varchar(100) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`campaign_archive_id`),
  KEY `campaign_type_id` (`campaign_type_id`),
  KEY `responsible_employee_id` (`responsible_employee_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `product_id` (`product_id`),
  KEY `campaign_group_id` (`campaign_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_campaign_contact`
--

CREATE TABLE IF NOT EXISTS `blzdsk_campaign_contact` (
  `campaign_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL,
  `campaign_related_id` int(11) NOT NULL,
  `campaign_status` tinyint(4) NOT NULL COMMENT '1. Contact 2. Account 3. Lead 4. Opporutnity',
  `is_delete` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `status` int(11) NOT NULL COMMENT '0-inactive,1- Active',
  PRIMARY KEY (`campaign_contact_id`),
  KEY `campaign_id` (`campaign_id`,`campaign_related_id`),
  KEY `contact_id` (`campaign_related_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_campaign_files_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_campaign_files_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL COMMENT 'campaign master id',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  KEY `campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_campaign_group_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_campaign_group_master` (
  `campaign_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) NOT NULL,
  `group_owner_id` int(11) NOT NULL,
  `group_description` longtext NOT NULL,
  `branch_id` int(11) NOT NULL COMMENT 'FK(branch_master)',
  `product_id` int(11) NOT NULL COMMENT 'FK(product_master)',
  `status_id` tinyint(4) NOT NULL COMMENT '1-prospect,2-lead,3-client',
  `value_start` int(11) NOT NULL,
  `value_end` int(11) DEFAULT NULL,
  `emp_owner_id` int(11) NOT NULL COMMENT 'FK(contact_master)',
  `previous_campaign_id` int(11) NOT NULL COMMENT 'FK(campaign)',
  `related_campaign` tinyint(4) NOT NULL,
  `campaign_id` int(11) NOT NULL COMMENT 'FK(campaign)',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`campaign_group_id`),
  KEY `branch_id` (`branch_id`),
  KEY `product_id` (`product_id`),
  KEY `previous_campaign_id` (`previous_campaign_id`),
  KEY `emp_owner_id` (`emp_owner_id`),
  KEY `campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_campaign_group_sales_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_campaign_group_sales_master` (
  `camp_group_sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_group_id` int(11) NOT NULL COMMENT 'FK(campaign_group_master)',
  `status_type` int(11) NOT NULL,
  `prospect_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive',
  PRIMARY KEY (`camp_group_sales_id`),
  KEY `campaign_group_id` (`campaign_group_id`),
  KEY `prospect_id` (`prospect_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_campaign_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_campaign_master` (
  `campaign_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(200) NOT NULL,
  `campaign_auto_id` varchar(20) NOT NULL,
  `campaign_type_id` varchar(255) NOT NULL,
  `responsible_employee_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `campaign_description` longtext NOT NULL,
  `budget_requirement` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `budget_ammount` int(11) NOT NULL,
  `campaign_supplier` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `supplier_id` int(11) NOT NULL,
  `revenue_goal` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `revenue_amount` int(11) NOT NULL,
  `related_product` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `product_id` varchar(255) DEFAULT NULL,
  `campaign_group_id` int(11) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`campaign_id`),
  KEY `campaign_type_id` (`campaign_type_id`),
  KEY `responsible_employee_id` (`responsible_employee_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `product_id` (`product_id`),
  KEY `campaign_group_id` (`campaign_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_campaign_product_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_campaign_product_tran` (
  `campaign_pro_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL COMMENT 'FK(campaign)',
  `product_id` int(11) NOT NULL COMMENT 'FK(product)',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`campaign_pro_id`),
  KEY `campaign_id` (`campaign_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_campaign_receipents_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_campaign_receipents_tran` (
  `campaign_res_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL COMMENT 'FK(campaign)',
  `contact_id` int(11) NOT NULL COMMENT 'FK(contact)',
  `recipient_type` varchar(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`campaign_res_id`),
  KEY `campaign_id` (`campaign_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_campaign_responsible_employee_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_campaign_responsible_employee_tran` (
  `campaign_responsible_employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL COMMENT 'FK(campaign)',
  `user_id` int(11) NOT NULL COMMENT 'FK(contact)',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`campaign_responsible_employee_id`),
  KEY `campaign_id` (`campaign_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_campaign_type_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_campaign_type_master` (
  `camp_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `camp_type_name` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`camp_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_chat_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_chat_master` (
  `chat_id` int(11) NOT NULL AUTO_INCREMENT,
  `contact1` int(11) NOT NULL COMMENT 'FK(contact_master)',
  `contact2` int(11) NOT NULL COMMENT 'FK(contact_master)',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT 'FK(contact_master) FK(contact_master)   1-active,0-inactive',
  PRIMARY KEY (`chat_id`),
  KEY `contact1` (`contact1`),
  KEY `contact2` (`contact2`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_chat_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_chat_tran` (
  `chat_conversation_id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_id` int(11) NOT NULL COMMENT 'FK(chat_master)',
  `conversation` text NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`chat_conversation_id`),
  KEY `chat_id` (`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_ci_sessions`
--

CREATE TABLE IF NOT EXISTS `blzdsk_ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_cms`
--

CREATE TABLE IF NOT EXISTS `blzdsk_cms` (
  `cms_id` int(11) NOT NULL AUTO_INCREMENT,
  `cms_name` varchar(255) NOT NULL,
  `cms_desc` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cms_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_communication_contact_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_communication_contact_tran` (
  `comm_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `comm_id` int(11) NOT NULL COMMENT 'FK(communication_sale)',
  `contact_id` int(11) NOT NULL COMMENT 'FK(contact)',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`comm_contact_id`),
  KEY `comm_id` (`comm_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_communication_sales`
--

CREATE TABLE IF NOT EXISTS `blzdsk_communication_sales` (
  `comm_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `date` date NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `employee_id` int(11) NOT NULL COMMENT 'FK(contact_master)',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`comm_id`),
  KEY `prospect_id` (`prospect_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_company_accounts_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_company_accounts_tran` (
  `company_accounts_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `status_type` tinyint(4) NOT NULL COMMENT '1-prospect,2-lead,3-WinClient,4-LostClient',
  `is_delete` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`company_accounts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_company_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_company_master` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(50) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `phone_no` varchar(50) NOT NULL,
  `website` varchar(100) NOT NULL,
  `address1` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country_id` int(11) NOT NULL,
  `company_id_data` varchar(255) NOT NULL,
  `reg_number` varchar(255) NOT NULL,
  `postal_code` varchar(25) NOT NULL,
  `logo_img` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `is_delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`company_id`),
  KEY `branch_id` (`branch_id`),
  KEY `branch_id_2` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_config`
--

CREATE TABLE IF NOT EXISTS `blzdsk_config` (
  `config_key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blzdsk_config`
--

INSERT INTO `blzdsk_config` (`config_key`, `value`) VALUES
('allowed_files', 'gif|jpg|png|pdf|doc|txt|docx|xls|zip|rar'),
('allow_client_registration', 'TRUE'),
('automatic_email_on_recur', 'TRUE'),
('base_url', ''),
('campaign_monitor_configuration', ''),
('company_profile_image', ''),
('dashboard_pm_widgets', '{"widgetOrder":["toDoWidget","projectStatWidget","taskStatWidget","summaryWidget","recentActivitiesWidget","fileUsageWidget"]} '),
('dashboard_widgets', '{"sectionLeft":["position-left-top","position-left-bottom"],"sectionRight":["position-right-top","position-right-bottom"]}'),
('date_format', 'm/d/Y'),
('demo_mode', 'FALSE'),
('developer', 'ig63Yd/+yuA8127gEyTz9TY4pnoeKq8dtocVP44+BJvtlRp8Vqcetwjk51dhSB6Rx8aVIKOPfUmNyKGWK7C/gg=='),
('email', 'info@blazedesk.nl'),
('email_notification_settings', ''),
('email_settings', ''),
('facebook_page_url', ''),
('general_settings', ''),
('get_response_configuration', ''),
('google_analytics_settings', ''),
('language', 'english'),
('linkedin_api_key', '-'),
('linkedin_company_id', '-'),
('mailchimp_configuration', ''),
('meta_author', 'C-Metric'),
('meta_contact', 'info@c-metri.com'),
('meta_description', 'description'),
('meta_keywords', 'keyword'),
('moosend_configuration', ''),
('newsletter_type', ''),
('project_logo', 'logo.png'),
('project_name', 'Blazedesk 3.0'),
('twitter_username', '                               ');

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_contact_files_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_contact_files_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_id` int(11) NOT NULL,
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `upload_status` int(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  `is_delete` int(2) NOT NULL COMMENT '0.No 1.Yes',
  PRIMARY KEY (`file_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_contact_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_contact_master` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `duplicate_contact_id` int(11) DEFAULT NULL,
  `is_duplicate` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `is_merge` int(11) NOT NULL DEFAULT '0' COMMENT '0.No 1.Yes',
  `merge_with` int(11) NOT NULL,
  `contact_name` varchar(50) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `company_id` int(11) NOT NULL,
  `job_title` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `logo_img` varchar(50) NOT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `postal_code` varchar(25) DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country_id` int(11) NOT NULL,
  `language_id` int(11) DEFAULT NULL COMMENT '1.english 2.spanish',
  `email` varchar(100) NOT NULL,
  `primary_contact` tinyint(4) NOT NULL COMMENT '1.selected',
  `contact_for` varchar(60) NOT NULL,
  `fb` varchar(250) DEFAULT NULL,
  `linkdin` varchar(250) DEFAULT NULL,
  `twitter` varchar(250) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `is_delete` tinyint(4) NOT NULL COMMENT '0.No 1.Yes',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `contact_type` tinyint(1) NOT NULL COMMENT '0:crm,1:support',
  `is_newsletter` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `configure_with` int(11) NOT NULL COMMENT '1 - mailchimp, 2 - Campaign Monitor, 3 - Moosend, 4 - Get Response ',
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_contact_task_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_contact_task_master` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_id` int(11) NOT NULL,
  `task_name` varchar(30) NOT NULL,
  `importance` varchar(20) NOT NULL,
  `remember` tinyint(4) NOT NULL,
  `before_status` tinyint(4) NOT NULL,
  `repeat` varchar(10) NOT NULL,
  `time` time NOT NULL,
  `remind_before_min` varchar(30) NOT NULL,
  `task_description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_delete` tinyint(4) NOT NULL COMMENT '0.No 1.Yes',
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`task_id`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_contarct_sales_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_contarct_sales_master` (
  `contract_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `contract_auto_id` varchar(20) NOT NULL,
  `contract_name` varchar(50) NOT NULL,
  `total_amt` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `frequency` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `cancelation_term` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` int(11) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`contract_id`),
  KEY `prospect_id` (`prospect_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_cost_files`
--

CREATE TABLE IF NOT EXISTS `blzdsk_cost_files` (
  `cost_file_id` int(11) NOT NULL AUTO_INCREMENT,
  `cost_id` int(11) NOT NULL COMMENT 'FK(cost_master)',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`cost_file_id`),
  KEY `cost_id` (`cost_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_cost_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_cost_master` (
  `cost_id` int(11) NOT NULL AUTO_INCREMENT,
  `cost_code` varchar(50) NOT NULL,
  `cost_name` varchar(255) NOT NULL,
  `project_id` int(11) NOT NULL COMMENT 'FK(project_master)',
  `task_id` int(11) NOT NULL COMMENT 'FK(task_master)',
  `user_id` int(11) NOT NULL COMMENT 'FK(user_master)',
  `cost_type` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `within_project` tinyint(4) DEFAULT '0' COMMENT '1-yes,0-no',
  `ammount` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `expense_supplier` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1-yes,0-no',
  `supplier_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `is_delete` tinyint(1) DEFAULT '0' COMMENT '1=Yes,0=No',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-planed,2-open,3-in process,4-completed',
  PRIMARY KEY (`cost_id`),
  KEY `project_id` (`project_id`),
  KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_cost_supplier_assigns`
--

CREATE TABLE IF NOT EXISTS `blzdsk_cost_supplier_assigns` (
  `cost_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  KEY `cost_id` (`cost_id`,`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_countries`
--

CREATE TABLE IF NOT EXISTS `blzdsk_countries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(250) NOT NULL,
  `country_code` varchar(255) NOT NULL,
  `currency_name` varchar(100) DEFAULT NULL,
  `currency_code` varchar(100) DEFAULT NULL,
  `currency_symbol` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `use_status` tinyint(4) DEFAULT NULL,
  `country_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 - InActive, 1-Active ',
  `is_delete_currency` tinyint(4) NOT NULL DEFAULT '0',
  `currency_amount` double(10,4) NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=242 ;

--
-- Dumping data for table `blzdsk_countries`
--

INSERT INTO `blzdsk_countries` (`country_id`, `country_name`, `country_code`, `currency_name`, `currency_code`, `currency_symbol`, `use_status`, `country_status`, `is_delete_currency`, `currency_amount`) VALUES
(1, 'Afghanistan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(2, 'Aringland Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(3, 'Albania', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(4, 'Algeria', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(5, 'American Samoa', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(6, 'Andorra', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(7, 'Angola', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(8, 'Anguilla', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(9, 'Antarctica', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(10, 'Antigua and Barbuda', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(11, 'Argentina', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(12, 'Armenia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(13, 'Aruba', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(14, 'Australia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(15, 'Austria', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(16, 'Azerbaijan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(17, 'Bahamas', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(18, 'Bahrain', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(19, 'Bangladesh', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(20, 'Barbados', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(21, 'Belarus', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(22, 'Belgium', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(23, 'Belize', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(24, 'Benin', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(25, 'Bermuda', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(26, 'Bhutan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(27, 'Bolivia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(28, 'Bosnia and Herzegovina', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(29, 'Botswana', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(30, 'Bouvet Island', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(31, 'Brazil', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(32, 'British Indian Ocean territory', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(33, 'Brunei Darussalam', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(34, 'Bulgaria', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(35, 'Burkina Faso', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(36, 'Burundi', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(37, 'Cambodia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(38, 'Cameroon', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(39, 'Canada', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(40, 'Cape Verde', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(41, 'Cayman Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(42, 'Central African Republic', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(43, 'Chad', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(44, 'Chile', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(45, 'China', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(46, 'Christmas Island', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(47, 'Cocos (Keeling) Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(48, 'Colombia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(49, 'Comoros', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(50, 'Congo', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(51, 'Congo', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(52, ' Democratic Republic', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(53, 'Cook Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(54, 'Costa Rica', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(55, 'Ivory Coast (Ivory Coast)', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(56, 'Croatia (Hrvatska)', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(57, 'Cuba', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(58, 'Cyprus', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(59, 'Czech Republic', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(60, 'Denmark', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(61, 'Djibouti', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(62, 'Dominica', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(63, 'Dominican Republic', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(64, 'East Timor', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(65, 'Ecuador', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(66, 'Egypt', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(67, 'El Salvador', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(68, 'Equatorial Guinea', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(69, 'Eritrea', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(70, 'Estonia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(71, 'Ethiopia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(72, 'Falkland Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(73, 'Faroe Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(74, 'Fiji', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(75, 'Finland', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(76, 'France', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(77, 'French Guiana', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(78, 'French Polynesia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(79, 'French Southern Territories', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(80, 'Gabon', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(81, 'Gambia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(82, 'Georgia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(83, 'Germany', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(84, 'Ghana', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(85, 'Gibraltar', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(86, 'Greece', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(87, 'Greenland', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(88, 'Grenada', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(89, 'Guadeloupe', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(90, 'Guam', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(91, 'Guatemala', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(92, 'Guinea', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(93, 'Guinea-Bissau', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(94, 'Guyana', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(95, 'Haiti', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(96, 'Heard and McDonald Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(97, 'Honduras', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(98, 'Hong Kong', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(99, 'Hungary', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(100, 'Iceland', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(101, 'India', '', 'Rupee', 'Rupee', '&', 0, 0, 1, 0.0000),
(102, 'Indonesia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(103, 'Iran', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(104, 'Iraq', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(105, 'Ireland', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(106, 'Israel', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(107, 'Italy', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(108, 'Jamaica', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(109, 'Japan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(110, 'Jordan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(111, 'Kazakhstan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(112, 'Kenya', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(113, 'Kiribati', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(114, 'Korea (north)', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(115, 'Korea (south)', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(116, 'Kuwait', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(117, 'Kyrgyzstan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(118, 'Lao People''s Democratic Republic', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(119, 'Latvia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(120, 'Lebanon', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(121, 'Lesotho', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(122, 'Liberia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(123, 'Libyan Arab Jamahiriya', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(124, 'Liechtenstein', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(125, 'Lithuania', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(126, 'Luxembourg', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(127, 'Macao', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(128, 'Macedonia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(129, 'Madagascar', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(130, 'Malawi', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(131, 'Malaysia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(132, 'Maldives', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(133, 'Mali', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(134, 'Malta', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(135, 'Marshall Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(136, 'Martinique', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(137, 'Mauritania', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(138, 'Mauritius', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(139, 'Mayotte', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(140, 'Mexico', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(141, 'Micronesia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(142, 'Moldova', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(143, 'Monaco', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(144, 'Mongolia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(145, 'Montserrat', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(146, 'Morocco', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(147, 'Mozambique', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(148, 'Myanmar', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(149, 'Namibia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(150, 'Nauru', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(151, 'Nepal', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(152, 'Netherlands', '', 'Euro', 'EUR', 'â‚¬', 1, 1, 0, 0.0000),
(153, 'Netherlands Antilles', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(154, 'New Caledonia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(155, 'New Zealand', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(156, 'Nicaragua', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(157, 'Niger', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(158, 'Nigeria', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(159, 'Niue', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(160, 'Norfolk Island', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(161, 'Northern Mariana Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(162, 'Norway', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(163, 'Oman', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(164, 'Pakistan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(165, 'Palau', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(166, 'Palestinian Territories', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(167, 'Panama', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(168, 'Papua New Guinea', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(169, 'Paraguay', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(170, 'Peru', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(171, 'Philippines', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(172, 'Pitcairn', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(173, 'Poland', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(174, 'Portugal', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(175, 'Puerto Rico', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(176, 'Qatar', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(177, 'Runion', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(178, 'Romania', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(179, 'Russian Federation', '', 'Rouble', 'RUB', ' â‚½', 1, 1, 0, 0.0000),
(180, 'Rwanda', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(181, 'Saint Helena', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(182, 'Saint Kitts and Nevis', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(183, 'Saint Lucia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(184, 'Saint Pierre and Miquelon', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(185, 'Saint Vincent and the Grenadines', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(186, 'Samoa', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(187, 'San Marino', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(188, 'Sao Tome and Principe', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(189, 'Saudi Arabia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(190, 'Senegal', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(191, 'Serbia and Montenegro', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(192, 'Seychelles', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(193, 'Sierra Leone', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(194, 'Singapore', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(195, 'Slovakia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(196, 'Slovenia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(197, 'Solomon Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(198, 'Somalia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(199, 'South Africa', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(200, 'South Georgia and the South Sandwich Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(201, 'Spain', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(202, 'Sri Lanka', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(203, 'Sudan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(204, 'Suriname', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(205, 'Svalbard and Jan Mayen Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(206, 'Swaziland', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(207, 'Sweden', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(208, 'Switzerland', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(209, 'Syria', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(210, 'Taiwan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(211, 'Tajikistan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(212, 'Tanzania', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(213, 'Thailand', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(214, 'Togo', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(215, 'Tokelau', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(216, 'Tonga', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(217, 'Trinidad and Tobago', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(218, 'Tunisia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(219, 'Turkey', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(220, 'Turkmenistan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(221, 'Turks and Caicos Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(222, 'Tuvalu', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(223, 'Uganda', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(224, 'Ukraine', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(225, 'United Arab Emirates', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(226, 'United Kingdom', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(227, 'United States of America', '', 'USD', 'USD', '$', 1, 1, 0, 0.0000),
(228, 'Uruguay', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(229, 'Uzbekistan', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(230, 'Vanuatu', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(231, 'Vatican City', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(232, 'Venezuela', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(233, 'Vietnam', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(234, 'Virgin Islands (British)', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(235, 'Virgin Islands (US)', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(236, 'Wallis and Futuna Islands', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(237, 'Western Sahara', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(238, 'Yemen', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(239, 'Zaire', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(240, 'Zambia', '', NULL, NULL, '', NULL, 0, 0, 0.0000),
(241, 'Zimbabwe', '', NULL, NULL, '', NULL, 0, 0, 0.0000);

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_crm_cases`
--

CREATE TABLE IF NOT EXISTS `blzdsk_crm_cases` (
  `cases_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `cases_type_id` int(11) NOT NULL COMMENT 'Fk-crm_cases_type',
  `business_cases` varchar(500) NOT NULL,
  `business_subject` varchar(250) NOT NULL,
  `responsible` int(11) NOT NULL,
  `deadline` date NOT NULL,
  `incident_status` int(11) NOT NULL,
  `description` text NOT NULL,
  `file` varchar(100) NOT NULL,
  `cases_related_id` int(11) NOT NULL,
  `cases_status` tinyint(4) NOT NULL COMMENT '1. Contact 2. Account 3. Lead 4. Opporutnity',
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Yes,0=No',
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`cases_id`),
  KEY `project_id` (`cases_related_id`,`created_by`,`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_crm_cases_files_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_crm_cases_files_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_file_id` int(11) NOT NULL,
  `cases_related_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `cases_status` tinyint(4) NOT NULL COMMENT '1. Contact 2. Account 3. Lead 4. Opporutnity',
  `file_name` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `upload_status` tinyint(1) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `type` tinyint(4) NOT NULL COMMENT '1-folder,2-file',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`file_id`),
  KEY `prospect_id` (`cases_related_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_crm_cases_type`
--

CREATE TABLE IF NOT EXISTS `blzdsk_crm_cases_type` (
  `cases_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `cases_type_name` varchar(100) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Yes,0=No',
  `status` tinyint(1) NOT NULL COMMENT '1-active,0-deactive',
  PRIMARY KEY (`cases_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_crm_job_title`
--

CREATE TABLE IF NOT EXISTS `blzdsk_crm_job_title` (
  `job_title_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_title_name` varchar(100) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Yes,0=No',
  `status` tinyint(1) NOT NULL COMMENT '1-active,0-deactive',
  PRIMARY KEY (`job_title_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_deal_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_deal_master` (
  `deal_id` int(11) NOT NULL AUTO_INCREMENT,
  `deal_name` varchar(50) NOT NULL,
  `deal_description` text NOT NULL,
  `owner_id` int(11) NOT NULL COMMENT 'FK(contact)',
  `company_id` int(11) NOT NULL COMMENT 'FK(company)',
  `contact_id` int(11) NOT NULL COMMENT 'FK(contact)',
  `start_date` date NOT NULL,
  `end_date` int(11) NOT NULL,
  `estimate_win_changes` int(3) NOT NULL,
  `estimated_worth` varchar(50) NOT NULL,
  `library_file` varchar(100) NOT NULL,
  `upload_file` varchar(100) NOT NULL,
  `deal_status` tinyint(4) NOT NULL COMMENT '1-prospect,2-lead,3-client',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`deal_id`),
  KEY `owner_id` (`owner_id`),
  KEY `company_id` (`company_id`,`contact_id`),
  KEY `start_date` (`start_date`),
  KEY `contact_id` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_deal_sales`
--

CREATE TABLE IF NOT EXISTS `blzdsk_deal_sales` (
  `deal_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `deal_name` varchar(100) NOT NULL,
  `deal_worth` float NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  PRIMARY KEY (`deal_id`),
  KEY `prospect_id` (`prospect_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_email_client_attachments`
--

CREATE TABLE IF NOT EXISTS `blzdsk_email_client_attachments` (
  `auto_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid_email` int(11) NOT NULL,
  `email_id` bigint(20) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `boxtype_file` varchar(50) DEFAULT NULL,
  `file_name_app` text,
  `file_size` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `is_local` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`auto_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_email_client_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_email_client_master` (
  `email_unq_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `to_mail` text,
  `from_mail` text,
  `cc_email` text,
  `bcc_email` text,
  `from_mail_address` text,
  `to_email_address` text,
  `reply_to_address` text,
  `reply_to_email` text,
  `send_date` text,
  `mail_subject` text,
  `uid` text,
  `msg_no` int(11) NOT NULL,
  `is_unread` int(11) DEFAULT NULL,
  `is_answered` int(11) DEFAULT NULL,
  `is_deleted` int(11) DEFAULT NULL,
  `mail_body` text CHARACTER SET utf8,
  `is_html` int(11) DEFAULT NULL,
  `is_starred` int(11) NOT NULL,
  `is_draft` tinyint(1) DEFAULT '0',
  `is_read` tinyint(4) NOT NULL,
  `is_flagged` int(11) NOT NULL,
  `is_local` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `header_data` text,
  `boxtype` varchar(100) DEFAULT NULL,
  `creation_date` datetime DEFAULT NULL,
  `sync_on` datetime DEFAULT NULL,
  PRIMARY KEY (`email_unq_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_email_communication`
--

CREATE TABLE IF NOT EXISTS `blzdsk_email_communication` (
  `comm_id` int(11) NOT NULL AUTO_INCREMENT,
  `comm_date` date NOT NULL,
  `comm_sender` int(11) NOT NULL COMMENT 'Id From Contact MAster',
  `comm_receiver` varchar(500) NOT NULL COMMENT 'Id From Contact MAster',
  `comm_subject` text NOT NULL,
  `comm_content` text NOT NULL,
  `comm_type` int(11) NOT NULL COMMENT '1- Event, 2- email Prospect, 3 - note',
  `comm_related_id` int(11) NOT NULL COMMENT 'Email Prospect Id',
  `email_prospect_id` int(11) NOT NULL,
  `note_id` int(11) DEFAULT NULL COMMENT 'id from note tbl',
  `is_delete` int(11) NOT NULL COMMENT '0-no, 1 yes',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`comm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_email_communication_files_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_email_communication_files_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `email_communication_id` int(11) NOT NULL COMMENT 'campaign master id',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_email_config`
--

CREATE TABLE IF NOT EXISTS `blzdsk_email_config` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(6) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `email_signature` text NOT NULL,
  `email_pass` varchar(150) NOT NULL,
  `email_server` varchar(100) NOT NULL,
  `email_port` int(11) NOT NULL,
  `email_encryption` varchar(50) NOT NULL,
  `email_smtp` varchar(100) NOT NULL,
  `email_smtp_port` int(5) NOT NULL,
  `account_folder` text,
  `mail_quota` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_email_prospect`
--

CREATE TABLE IF NOT EXISTS `blzdsk_email_prospect` (
  `email_prospect_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_auto_id` varchar(20) NOT NULL,
  `prospect_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `prospect_owner_id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `email_description` longtext NOT NULL,
  `send_to` text NOT NULL,
  `file_library` varchar(100) NOT NULL,
  `file_upload` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`email_prospect_id`),
  KEY `prospect_owner_id` (`prospect_owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_email_prospect_contact_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_email_prospect_contact_tran` (
  `email_prospect_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `email_prospect_id` int(11) NOT NULL COMMENT 'FK(email_prospect)',
  `contact_id` int(11) NOT NULL COMMENT 'FK(contact_master)',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`email_prospect_contact_id`),
  KEY `email_prospect_id` (`email_prospect_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_email_prospect_files_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_email_prospect_files_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `email_prospect_id` int(11) NOT NULL COMMENT 'campaign master id',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  KEY `email_prospect_id` (`email_prospect_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_email_template_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_email_template_master` (
  `template_id` int(11) NOT NULL AUTO_INCREMENT,
  `variable` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `system_template` tinyint(1) NOT NULL DEFAULT '0',
  `st_slug` varchar(10) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `is_delete` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `blzdsk_email_template_master`
--

INSERT INTO `blzdsk_email_template_master` (`template_id`, `variable`, `subject`, `body`, `created_date`, `modified_date`, `system_template`, `st_slug`, `status`, `is_delete`) VALUES
(2, '{USER}-{PROJECT} ', 'New Project Assigned', '<p>Hello {USER}</p>\r\n\r\n<p>You are assigned to a new Project named <b>{PROJECT}</b>.<br></p>\r\n\r\n<p>Sincerely,<br>The&nbsp; BLAZDESK Team</p>\r\n\r\n<p></p>', '2016-03-03 13:13:00', '2016-04-14 07:25:34', 1, '', 1, 0),
(3, '{USER}-{PROJECT}-{DATE}', 'Project Meeting Scheduled', 'Hello {USER}<br><p><br></p><p>your meeting has been scheduled on below details</p><p><span style="font-weight: bold;">Project Name:&nbsp; </span>{PROJECT}</p><p><span style="font-weight: bold;">Date:</span>{DATE}</p><p><br></p><p>Sincerely,<br>The&nbsp; BLAZDESK Team</p>', '2016-03-03 13:14:55', '0000-00-00 00:00:00', 1, '', 1, 0),
(29, '{PASS_KEY_URL}-{SITE_NAME}-', 'Forgot Password', '<p>Forgot Password</p>\r\n\r\n<p>To change your password,you can follow the link bellow.&nbsp;</p>\r\n\r\n<p>{PASS_KEY_URL}</p>\r\n\r\n<p>You are receiving this email because a user of&nbsp; {SITE_NAME} password requested again.</p>\r\n\r\n<p><span id="result_box" class="" lang="en"><span class="hps">This is a standard</span> <span class="hps">procedure</span> <span class="hps">from</span> <span class="hps">the system.</span> <span class="hps">If you do NOT</span> <span class="hps">have requested</span> <span class="hps">your password,</span> <span class="hps">please disregard</span> <span class="hps">this email</span><span>.</span> <span class="hps">Your password</span> <span class="hps">will remain</span> <span class="hps">in the old</span> <span class="hps">state.</span><br><br></span><br></p>\r\n\r\n<p>Sincerely,<br>The&nbsp; BLAZDESK Team</p>\r\n\r\n<p> <br></p>\r\n\r\n<p><br></p>', '2016-02-19 08:47:47', '2016-02-22 14:39:07', 1, '', 1, 0),
(31, '', 'Thank You', '<p>thanks for your support ticket our team will get back to you ASAP.</p><p><span style="background-color: yellow;">Thank You</span></p><p><span style="background-color: yellow;">Team Blazedesk.</span><br></p>', '2016-04-08 14:18:46', '0000-00-00 00:00:00', 1, '', 1, 0),
(36, '{USER}-{CREATE_USER}-{PROJECT}-{DESCRIPTION}-{TASK_NAME}', 'A task has been created', '<p style="line-height: 17.1429px;">Hello {USER},</p><p style="line-height: 17.1429px;"><br></p><p style="line-height: 17.1429px;">{CREATE_USER} has created a new task.</p><p style="line-height: 17.1429px;"><span style="font-weight: bold;">Project :&nbsp;</span>{PROJECT}<br></p><p style="line-height: 17.1429px;"><span style="font-weight: bold;">Task :&nbsp;</span>{TASK_NAME}</p><p style="line-height: 17.1429px;"><span style="font-weight: bold;">Task Description :</span>{DESCRIPTION}<span style="line-height: 17.1429px;"></span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px;"><br></span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px;">Sincerely,</span><br style="line-height: 17.1429px;"><span style="line-height: 17.1429px;">The&nbsp; BLAZDESK Team</span></p>', '2016-03-07 09:38:44', '2016-04-14 07:24:46', 1, '', 1, 0),
(37, '{USER}-{CREATE_USER}-{PROJECT}-{DESCRIPTION}', 'Task  {TASK_NAME} has been updated', '<p style="line-height: 17.1429px;">Hello {USER},</p><p style="line-height: 17.1429px;"><br></p><p style="line-height: 17.1429px;">{CREATE_USER} Had updated the task below.</p><p style="line-height: 17.1429px;"><span style="font-weight: bold;">Project :&nbsp;</span>{PROJECT}<br></p><p style="line-height: 17.1429px;"><span style="font-weight: bold;">Task :&nbsp;</span>{TASK_NAME}</p><p style="line-height: 17.1429px;"><span style="font-weight: bold;">Task Description :</span>{DESCRIPTION}<span style="line-height: 17.1429px;"></span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px;"><br></span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px;">Sincerely,</span><br style="line-height: 17.1429px;"><span style="line-height: 17.1429px;">The&nbsp; BLAZDESK Team</span></p>', '2016-03-07 12:56:54', '2016-04-14 07:21:21', 1, '', 1, 0),
(38, '{USER}-{LIVE_LINK}', 'Send Estimate', '<p>Hello {USER},</p><p><br></p><p>You can accept Estimate online, Please click on following link.<br></p><span style="font-weight: bold;">Link: </span>{LIVE_LINK}<br><p><br></p><p>Sincerely,<br>The&nbsp; BLAZDESK Team <br></p><br><p></p><p></p>', '2016-03-11 10:53:12', '2016-03-11 10:53:36', 1, '', 1, 0),
(39, '{USER}', 'Send Estimate With PDF', '<p><p>Dear {USER},</p><p><br></p><p>Thank you for providing us the opportunity to send you a proposal for the requested products and services.<br></p>In the attachment we have added the requested estimation. If you have any questions or remarks feel free to contact me.<br><p><br></p><p>Sincerely,<br>The&nbsp; BLAZDESK Team</p><br></p>', '2016-03-03 13:13:00', '2016-04-14 07:24:02', 1, '', 1, 0),
(40, '{USER}', 'Send invoice', '<p><span style="line-height: 1.42857;">Hello {USER},</span></p><p><span style="line-height: 1.42857;"><br></span><span style="line-height: 1.42857;">Please find your invoice for more information.</span><br></p><p><br></p><p><span style="font-weight: bold;">Blazedesk</span></p>', '2016-03-28 16:01:55', '2016-04-06 10:27:58', 1, '', 1, 0),
(51, '{USER}-{CREATE_USER}-{PROJECT}-{TASK_NAME}-{PROJECT_STATUS}-{DUE_DATE}-', 'Task has surpassed the deadline', '<p style="line-height: 17.1429px;">Hello {USER},</p><p style="line-height: 17.1429px;">{CREATE_USER} Did not completed the task bellow within the set deadline.</p><p style="line-height: 17.1429px;"><span style="font-weight: bold;">Project :&nbsp;</span>{PROJECT}<br></p><p style="line-height: 17.1429px;"><span style="font-weight: bold;">Task :&nbsp;</span>{TASK_NAME}</p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px; font-weight: bold;">Status</span><span style="line-height: 17.1429px; font-weight: bold;">:&nbsp;</span><span style="line-height: 17.1429px;">{PROJECT_STATUS}</span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px; font-weight: bold;">Due Date</span><span style="line-height: 17.1429px; font-weight: bold;">:&nbsp;</span><span style="line-height: 17.1429px;">{DUE_DATE}</span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px;"><br></span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px;">Sincerely,</span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px;"><br></span><br style="line-height: 17.1429px;"><span style="line-height: 17.1429px;">The&nbsp; BLAZDESK Team</span></p>', '2016-04-08 05:00:06', '2016-04-14 07:20:24', 1, '', 1, 0),
(52, '{USER_NAME}-{LOGIN_URL}', 'Welcome To Blazedeskcrm ', '<p>Dear&nbsp;<span style="line-height: 17.1429px;">&nbsp;</span><span style="line-height: 17.1429px;">{USER_NAME} ,</span></p><p><span style="line-height: 1.42857;">Welcome to BLAZEDESK,</span><br></p><p>You can start using BLAZEDESK from below URL.</p><p><br></p><p>{LOGIN_URL}</p><p><span style="line-height: 1.42857;"><br></span></p><p><span style="line-height: 1.42857;">Sincerely,</span><br></p><p><span style="line-height: 17.1429px;">The&nbsp; BLAZDESK Team.</span></p>', '2016-04-14 13:14:19', '2016-04-14 16:26:11', 1, '', 1, 0),
(55, '{USER}-{OPPORTUNITY_NAME}-{LINK}-{TYPE}', 'Blazedesk:{TYPE} Owner Change Notification', '<p>Hello {USER}</p><p>New {TYPE}&nbsp; {OPPORTUNITY_NAME}&nbsp; has been added to your contact</p><p>you can view it by clicking&nbsp; {LINK}<br></p><p>Regards </p><p>Blazedesk<br></p>', '2016-04-16 06:39:00', '0000-00-00 00:00:00', 1, '', 1, 0),
(56, '', 'Support Meeting Schedule', 'Support Meeting Schedule', '2016-04-16 06:39:00', '0000-00-00 00:00:00', 1, '', 1, 0),
(57, '', 'Your meeting has been scheduled on below details', '<p style="line-height: 17.1429px;">Hello,<br></p><p style="line-height: 17.1429px;">You have new meeting schedule. Your meeting details are given below.</p>Meeting Title : {MEETING_TITLE}<p>Meeting Date : {MEETING_DATE}</p><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using ''Content here, content here'', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for ''lorem ipsum'' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</span><br>', '2016-04-18 13:21:40', '2016-04-18 13:05:10', 1, 'ST_7654', 1, 0),
(58, '', 'Updated Meeting Schedule', '<p>Hello,<br></p>\r\n\r\n<p>You have new meeting schedule. Your meeting details are given below.</p>Meeting Title : {MEETING_TITLE}<p>Meeting Date : {MEETING_DATE}</p><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using ''Content here, content here'', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for ''lorem ipsum'' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</span><br>', '2016-04-18 13:22:46', '2016-04-18 13:05:22', 1, 'ST_1535', 1, 0),
(59, '{USER}-{TASK_NAME}-{IMPORTANCE}-{START_DATE}-{END_DATE}', 'To do reminder', '<p style="line-height: 17.1429px;">Hello {USER},</p><p style="line-height: 17.1429px;"><br></p><p style="line-height: 17.1429px;">To do remainder for below task.</p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px; font-weight: bold;">Task :&nbsp;</span><span style="line-height: 17.1429px;">{TASK_NAME}</span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px;"><span style="font-weight: bold;">Importance&nbsp;</span>:&nbsp;{IMPORTANCE}</span><br></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px; font-weight: bold;">Start Date:&nbsp;</span><span style="line-height: 17.1429px;">{START_DATE}</span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px; font-weight: bold;">Due &nbsp;Date</span><span style="line-height: 17.1429px; font-weight: bold;">:&nbsp;</span><span style="line-height: 17.1429px;">{END_DATE}<br></span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px;"><br></span></p><p style="line-height: 17.1429px;"><span style="line-height: 17.1429px;">Sincerely,</span><br style="line-height: 17.1429px;"><span style="line-height: 17.1429px;">The&nbsp; BLAZDESK Team</span></p>', '2016-04-18 13:57:21', '2016-04-18 17:35:22', 1, '', 1, 0),
(60, '{USER}-{LEAD_NAME}', 'Blazedesk:Qualify Lead', '<p>Hello {USER}</p><p> Lead <b>{LEAD_NAME}</b>&nbsp; has been Qualified </p><p>Regards </p><p>Blazedesk<br></p>', '2016-04-16 06:39:00', '0000-00-00 00:00:00', 1, '', 1, 0),
(61, '{USER}-{OPPORTUNITY_NAME}', 'Blazedesk:Opportunity Won', '<p>Hello {USER}</p><p> Opportunity <b>{OPPORTUNITY_NAME}</b>&nbsp; has been Won</p><p>Regards </p><p>Blazedesk<br></p>', '2016-04-16 06:39:00', '0000-00-00 00:00:00', 1, '', 1, 0),
(62, '{USER}-{OPPORTUNITY_NAME}', 'Blazedesk:Opportunity Lost', '<p>Hello {USER}</p><p> Opportunity <b>{OPPORTUNITY_NAME}</b>&nbsp; has been Lost</p><p>Regards </p><p>Blazedesk<br></p>', '2016-04-16 06:39:00', '0000-00-00 00:00:00', 1, '', 1, 0),
(65, '{USER}-{STATUS}-{CLIENT_NAME}-{EST-CODE}', 'Client Estimate Status', '<p>Hello {USER}</p><p>Following is your Estimate related details.</p><P>Estimate Code: {EST-CODE}</P><P>Client Name: {CLIENT_NAME}</P><P>Estimate Status: {STATUS}</P><p>Sincerely,<br>The BLAZDESK Team</p>', '2016-03-03 13:13:00', '2016-03-03 14:10:00', 1, '', 1, 0),
(66, '{USER}-{EST-CODE}', 'Estimate Due Date Notification', '<p>Hello {USER}</p><p>Your Estimate Due date is tomorrow and some Users are still not accept it.</p><P>Estimate code: {EST-CODE}</P><p>Sincerely,<br>The&nbsp; BLAZDESK Team</p>', '2016-03-03 13:13:00', '2016-03-03 13:13:00', 1, '', 1, 0),
(67, '{EVENT_TITLE}-{EVENT_DATE}-{EVENT_PLACE}-{EVENT_NOTE}', 'Event Reminder', '<p>Hello All,</p><p><br>Event reminder.</p><p>Event Title : {EVENT_TITLE}</p><p>EventDate :&nbsp; {EVENT_DATE}</p><p>Event Place : {EVENT_PLACE}</p><p>Event Note: {EVENT_NOTE}</p><p><br/><p>Thank you,</p><p>BLAZEDESK<br></p>', '2016-05-18 00:00:00', '0000-00-00 00:00:00', 1, '', 1, 0),
(68, '', 'New Message Generated For You', '<p>Hello,</p><p>There is new message generated for you.</p><p>Your Message details are given below.</p><p><br></p><p><span style="font-weight: bold;">Message Subject</span>&nbsp; :&nbsp; {MESSAGE_SUBJECT}</p><p><span style="font-weight: bold;">Message Description</span> :&nbsp; {MESSAGE_DESCRIPTION}</p><p><br>Thank You, </p><p>{FROM_NAME}<br></p>', '2016-05-03 10:39:55', '2016-05-03 10:55:05', 1, 'ST_8686', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_client`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_client` (
  `est_client_id` int(11) NOT NULL AUTO_INCREMENT,
  `estimate_id` int(11) NOT NULL,
  `prospect_id` int(11) NOT NULL COMMENT 'prospect_id as a client',
  `client_type` varchar(11) NOT NULL,
  `client_name` varchar(25) DEFAULT NULL,
  `recipient_id` int(11) NOT NULL,
  `recipient_type` varchar(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`est_client_id`),
  KEY `estimate_id` (`estimate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_client_approval`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_client_approval` (
  ` estimate_client_approval_id` int(11) NOT NULL AUTO_INCREMENT,
  `estimate_id` int(11) NOT NULL,
  `estimate_auto_id` varchar(255) NOT NULL,
  `est_client_id` int(11) NOT NULL,
  `signature` text,
  `signature_type` varchar(255) NOT NULL,
  `client_can_accept_online_textbox` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1-inactive, 0-active',
  `est_client_approval_status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (` estimate_client_approval_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_files`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `estimate_id` int(11) NOT NULL COMMENT 'FK(est_master)',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  KEY `estimate_id` (`estimate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_master` (
  `estimate_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_id` int(20) NOT NULL,
  `prospect_owner_id` int(11) DEFAULT NULL,
  `estimate_auto_id` varchar(30) NOT NULL,
  `login_id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `est_content` longtext NOT NULL,
  `value` float(10,2) NOT NULL,
  `send_date` date NOT NULL,
  `due_date` date NOT NULL,
  `discount` float(10,2) DEFAULT NULL,
  `discount_option` varchar(11) NOT NULL DEFAULT 'prsnt',
  `country_id` int(11) DEFAULT NULL,
  `country_id_symbol` int(11) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `est_userdescription_status` tinyint(1) NOT NULL DEFAULT '0',
  `est_userdescription` longtext,
  `est_termcondition` text,
  `text_paragraph` longtext,
  `signature` longtext,
  `signature_type` tinyint(1) DEFAULT NULL,
  `signature_date` date DEFAULT '0000-00-00',
  `signature_place` varchar(25) DEFAULT NULL,
  `signature_name` varchar(50) DEFAULT NULL,
  `signature_jobrole` varchar(25) DEFAULT NULL,
  `client_can_accept_online` tinyint(1) DEFAULT NULL,
  `client_can_accept_online_textbox` varchar(255) DEFAULT NULL,
  `est_content_widgets` text,
  `est_header_widget` text,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0-inactive, 1-active, 2-Draft, 3-delete',
  PRIMARY KEY (`estimate_id`),
  KEY `country_id_symbol` (`country_id_symbol`),
  KEY `login_id` (`login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_product`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_product` (
  `est_prd_id` int(11) NOT NULL AUTO_INCREMENT,
  `estimate_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_group_id` bigint(20) DEFAULT NULL,
  `product_qty` int(11) NOT NULL,
  `product_tax` int(11) DEFAULT NULL,
  `product_discount` float(10,2) DEFAULT NULL,
  `product_disoption` varchar(11) DEFAULT NULL,
  `product_sales_price` decimal(12,2) DEFAULT NULL,
  `product_name` varchar(100) DEFAULT NULL COMMENT 'Product name for Estimate',
  `product_description` text COMMENT 'Product Description for Estimate',
  `product_amt` float(10,2) NOT NULL,
  `product_order` int(11) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `est_prd_grp_id` int(11) NOT NULL,
  PRIMARY KEY (`est_prd_id`),
  KEY `estimate_id` (`estimate_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_product_group`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_product_group` (
  `est_prd_grp_id` int(25) NOT NULL AUTO_INCREMENT,
  `estimate_id` int(11) NOT NULL,
  `product_group_id` int(11) NOT NULL,
  `product_group_total_amt` int(11) DEFAULT NULL,
  `product_group_discounted_amt` int(11) DEFAULT NULL,
  `product_group_tax_amt` int(11) DEFAULT NULL,
  `product_group_qty` int(11) DEFAULT NULL,
  PRIMARY KEY (`est_prd_grp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_prospect`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_prospect` (
  `estimate_prospect_id` int(11) NOT NULL AUTO_INCREMENT,
  `estimate_auto_id` varchar(20) NOT NULL,
  `prospect_name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `estimated_total` int(8) NOT NULL,
  `costs` int(8) NOT NULL,
  `profit` int(8) NOT NULL,
  `responsible_emp_id` int(11) NOT NULL COMMENT 'FK(contact)',
  `estimate_description` text NOT NULL,
  `created_date` int(11) NOT NULL,
  `modified_date` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`estimate_prospect_id`),
  KEY `responsible_emp_id` (`responsible_emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_prospect_contact_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_prospect_contact_tran` (
  `estimate_prospect_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `estimate_prospect_id` int(11) NOT NULL COMMENT 'FK(estimate_prospect)',
  `file` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`estimate_prospect_contact_id`),
  KEY `estimate_prospect_id` (`estimate_prospect_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_send_est`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_send_est` (
  `est_send_id` int(11) NOT NULL AUTO_INCREMENT,
  `estimate_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `recipient_type` varchar(11) NOT NULL,
  `recipient_autograph` int(11) DEFAULT NULL,
  `est_open_onetime_status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1- Active, 0 - Inactive',
  `created_date` int(11) NOT NULL,
  `est_send_status` tinyint(4) NOT NULL COMMENT '0 - Inactive, 1 - Active',
  PRIMARY KEY (`est_send_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_settings`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_settings` (
  `estimate_settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `terms` longtext NOT NULL,
  `conditions` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`estimate_settings_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `blzdsk_estimate_settings`
--

INSERT INTO `blzdsk_estimate_settings` (`estimate_settings_id`, `name`, `terms`, `conditions`, `status`, `is_delete`) VALUES
(1, 'Default ', '<p>This is&nbsp;Default &nbsp;Terms &amp; Conditions&nbsp;</p><p class="c4"><span class="c3">Your use of the Services is subject to your\r\n  creation and our approval of an AdSense account (an\r\n  â€œ</span><span class="c1">Account</span><span class="c3">â€).\r\n  &nbsp;We have the right to refuse or limit your access to the Services. By\r\n  submitting an application to use the Services, if you are an individual, you\r\n  represent that you are at least 18 years of age. &nbsp;You may only have one\r\n  Account. &nbsp;</span></p>\r\n\r\n  <p class="c4"><span class="c3">By enrolling in AdSense, you permit Google to\r\n  serve, as applicable, (i) advertisements and other content\r\n  (â€œ</span><span class="c1">Ads</span><span class="c3">â€), (ii)\r\n  Google search boxes and search results, and (iii) related search queries and\r\n  other links to your websites, mobile applications, media players, mobile\r\n  content, and/or other properties approved by Google (each individually a\r\n  â€œ</span><span class="c1">Property</span><span class="c3">â€).\r\n  &nbsp;In addition, you grant Google the right to access, index and cache the\r\n  Properties, or any portion thereof, including by automated means. Google may\r\n  refuse to provide the Services to any Property.</span></p>\r\n\r\n  <p class="c4"><span class="c3">Any Property that is a software application\r\n  and accesses our Services (a) may require preapproval by Google in writing,\r\n  and (b) must comply with Googleâ€™s</span><span class="c3"><a target="_blank" class="c5" href="http://www.google.com/about/company/software-principles.html">&nbsp;</a></span><span class="c7 c3"><a target="_blank" class="c5" href="http://www.google.com/about/company/software-principles.html">Software\r\n  Principles</a></span><span class="c3">.</span></p>\r\n\r\n  <p class="c2"><br></p>', '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_template`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_template` (
  `est_temp_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Estimate Template Id',
  `est_temp_name` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`est_temp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_estimate_template_product`
--

CREATE TABLE IF NOT EXISTS `blzdsk_estimate_template_product` (
  `est_temp_prd_id` int(11) NOT NULL AUTO_INCREMENT,
  `est_temp_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_group_id` bigint(20) DEFAULT NULL,
  `product_qty` int(11) NOT NULL,
  `product_tax` int(11) DEFAULT NULL,
  `product_discount` float(10,2) NOT NULL,
  `product_disoption` varchar(11) NOT NULL,
  `product_amt` float(10,2) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`est_temp_prd_id`),
  KEY `est_temp_id` (`est_temp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_events`
--

CREATE TABLE IF NOT EXISTS `blzdsk_events` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `meeting_master_id` int(11) DEFAULT NULL COMMENT 'if event generated from schedule meeting',
  `event_related_id` int(11) NOT NULL,
  `event_title` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `event_remember` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `reminder_date` date NOT NULL,
  `reminder_time` time NOT NULL,
  `event_note` text NOT NULL,
  `event_time` time NOT NULL,
  `event_place` text NOT NULL,
  `event_image` varchar(255) NOT NULL,
  `event_status` int(11) NOT NULL COMMENT '1- contact, 2- account, 3 - Lead, 4- Opportunity ',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0.No 1.Yes',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `contact_id` (`event_related_id`),
  KEY `contact_id_2` (`event_related_id`),
  KEY `contact_id_3` (`event_related_id`),
  KEY `contact_id_4` (`event_related_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_files_lead_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_files_lead_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_file_id` int(11) NOT NULL,
  `lead_id` int(11) NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `type` tinyint(4) NOT NULL COMMENT '1-folder,2-file',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`file_id`),
  KEY `prospect_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_files_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_files_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_file_id` int(11) NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1-folder,2-file',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_files_sales_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_files_sales_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_file_id` int(11) NOT NULL,
  `prospect_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `file_name` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `type` tinyint(4) NOT NULL COMMENT '1-folder,2-file',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`file_id`),
  KEY `prospect_id` (`prospect_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_files_ticket_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_files_ticket_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_file_id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `type` tinyint(4) NOT NULL COMMENT '1-folder,2-file',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`file_id`),
  KEY `prospect_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_invoice_sales_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_invoice_sales_master` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_id` int(11) NOT NULL,
  `invoice_auto_id` varchar(20) NOT NULL COMMENT 'FK(prospect_master)',
  `deal_id` int(11) NOT NULL COMMENT 'FK(deal_sales)',
  `days_open` int(3) NOT NULL,
  `invoice_date` date NOT NULL,
  `due_date` date NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`invoice_id`),
  KEY `prospect_id` (`prospect_id`,`deal_id`),
  KEY `deal_id` (`deal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_knowledgebase_knowledge_article`
--

CREATE TABLE IF NOT EXISTS `blzdsk_knowledgebase_knowledge_article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_name` varchar(150) NOT NULL,
  `main_category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `article_description` text NOT NULL,
  `client_visible` tinyint(4) NOT NULL,
  `article_owner` varchar(100) NOT NULL,
  `product_related` tinyint(4) NOT NULL,
  `product_id` varchar(150) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive',
  `is_delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_knowledgebase_like`
--

CREATE TABLE IF NOT EXISTS `blzdsk_knowledgebase_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `like` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_knowledgebase_main_category`
--

CREATE TABLE IF NOT EXISTS `blzdsk_knowledgebase_main_category` (
  `main_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(150) NOT NULL,
  `type_id` int(11) NOT NULL,
  `client_visible` tinyint(4) NOT NULL,
  `article_owner` varchar(100) NOT NULL,
  `product_related` tinyint(4) NOT NULL,
  `product_id` varchar(150) DEFAULT NULL,
  `icon_image` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive',
  `is_delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`main_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_knowledgebase_sub_category`
--

CREATE TABLE IF NOT EXISTS `blzdsk_knowledgebase_sub_category` (
  `sub_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_category_name` varchar(150) NOT NULL,
  `main_category_id` int(11) NOT NULL,
  `client_visible` tinyint(4) NOT NULL,
  `article_owner` varchar(100) NOT NULL,
  `product_related` tinyint(4) NOT NULL,
  `product_id` varchar(150) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive',
  `is_delete` tinyint(4) NOT NULL,
  PRIMARY KEY (`sub_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_knowledge_base_settings_type`
--

CREATE TABLE IF NOT EXISTS `blzdsk_knowledge_base_settings_type` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_knowledge_file_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_knowledge_file_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_file_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `file_name` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `upload_status` tinyint(1) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `type` tinyint(4) NOT NULL COMMENT '1-folder,2-file',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`file_id`),
  KEY `article_id` (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_language_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_language_master` (
  `language_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_name` varchar(50) NOT NULL,
  `name` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `blzdsk_language_master`
--

INSERT INTO `blzdsk_language_master` (`language_id`, `language_name`, `name`) VALUES
(1, 'english', 'english'),
(2, 'spanish', 'EspaÃ±ol'),
(3, 'swedish', 'svensk'),
(4, 'russian', 'Ñ€ÑƒÑÑÐºÐ¸Ð¹'),
(5, 'croatian', 'hrvatski'),
(6, 'danish', 'dansk'),
(7, 'french', 'franÃ§ais'),
(8, 'japanese', 'æ—¥æœ¬èªž'),
(9, 'norwegian', 'norsk'),
(10, 'portugese', 'portuguÃªs'),
(11, 'romanian', 'RomÃ¢nÄƒ'),
(12, 'turkish', 'TÃ¼rk'),
(13, 'arabic', 'Ø§Ù„Ø¹Ø±Ø¨ÙŠØ©'),
(14, 'greek', 'ÎµÎ»Î»Î·Î½Î¹ÎºÎ¬'),
(15, 'Dutch', 'Dutch');

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_lead_contacts_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_lead_contacts_tran` (
  `pro_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `primary_contact` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`pro_contact_id`),
  KEY `prospect_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_lead_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_lead_master` (
  `lead_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_auto_id` varchar(20) NOT NULL,
  `prospect_name` varchar(50) NOT NULL,
  `status_type` tinyint(4) NOT NULL COMMENT '1-prospect,2-lead,3-client',
  `company_id` int(11) NOT NULL,
  `address1` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) NOT NULL,
  `country_id` int(11) NOT NULL,
  `number_type1` int(11) NOT NULL COMMENT '1.home 2.mobile 3.office',
  `phone_no` varchar(50) NOT NULL,
  `number_type2` int(11) NOT NULL,
  `phone_no2` varchar(20) DEFAULT NULL,
  `prospect_owner_id` int(11) NOT NULL,
  `language_id` int(11) DEFAULT NULL,
  `branch_id` int(11) NOT NULL COMMENT 'FK(branch_master)',
  `estimate_prospect_worth` varchar(20) DEFAULT NULL,
  `prospect_generate` tinyint(4) NOT NULL,
  `campaign_id` int(11) NOT NULL COMMENT 'FK(campaign)',
  `description` longtext NOT NULL,
  `file` varchar(100) NOT NULL,
  `fb` varchar(250) DEFAULT NULL,
  `twitter` varchar(250) DEFAULT NULL,
  `linkedin` varchar(250) DEFAULT NULL,
  `contact_date` date NOT NULL,
  `is_delete` tinyint(4) NOT NULL COMMENT '0.No 1.Yes',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`lead_id`),
  KEY `prospect_owner_id` (`prospect_owner_id`),
  KEY `branch_id` (`branch_id`),
  KEY `campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_lead_products_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_lead_products_tran` (
  `pro_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`pro_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_login`
--

CREATE TABLE IF NOT EXISTS `blzdsk_login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `salution_prefix` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `address_1` varchar(500) NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `country` int(11) DEFAULT NULL,
  `telephone1` varchar(50) NOT NULL,
  `telephone2` varchar(50) NOT NULL,
  `profile_photo` varchar(255) NOT NULL,
  `user_type` int(10) NOT NULL,
  `dashboard_widgets` text NOT NULL,
  `dashboard_pm_widgets` text NOT NULL,
  `blazedesk_pm_taskdashboardWidgets` text NOT NULL,
  `taskdashboardinnerWidgets` text NOT NULL,
  `dashboard_support_widgets` text,
  `salesoverview_dashboard_widgets` varchar(255) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `session_id` text NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `reset_password_token` varchar(255) NOT NULL,
  `is_delete` int(4) NOT NULL DEFAULT '0',
  `updated_by` int(11) NOT NULL,
  `is_crm_user` tinyint(4) NOT NULL DEFAULT '0',
  `is_pm_user` tinyint(4) NOT NULL DEFAULT '0',
  `is_support_user` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `blzdsk_login`
--

INSERT INTO `blzdsk_login` (`login_id`, `salution_prefix`, `firstname`, `lastname`, `email`, `password`, `address`, `address_1`, `city`, `state`, `pincode`, `country`, `telephone1`, `telephone2`, `profile_photo`, `user_type`, `dashboard_widgets`, `dashboard_pm_widgets`, `blazedesk_pm_taskdashboardWidgets`, `taskdashboardinnerWidgets`, `dashboard_support_widgets`, `salesoverview_dashboard_widgets`, `created_date`, `modified_date`, `session_id`, `parent_id`, `status`, `reset_password_token`, `is_delete`, `updated_by`, `is_crm_user`, `is_pm_user`, `is_support_user`) VALUES
(27, 0, 'lamton', 'j', 'lamton2015@gmail.com', '20f67f65a9feba35420d6978be77e950', 'Ahmedabad', '', '', '', '', 0, '+256782235406', '', '', 39, '', '', '', '', NULL, NULL, '2016-07-15 14:00:52', '2016-07-15 14:00:52', '', 0, 1, '', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_log_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_log_master` (
  `log_id` int(10) NOT NULL AUTO_INCREMENT,
  `login_id` int(10) NOT NULL,
  `ip_address` varchar(40) NOT NULL,
  `browser` text NOT NULL,
  `session_id` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_message_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_message_master` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_send_to` int(11) NOT NULL,
  `id_send_from` int(11) NOT NULL,
  `message_subject` varchar(500) NOT NULL,
  `message_description` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `is_delete` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `is_notified` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_milestone_files`
--

CREATE TABLE IF NOT EXISTS `blzdsk_milestone_files` (
  `milestone_file_id` int(11) NOT NULL AUTO_INCREMENT,
  `milestone_id` int(11) NOT NULL COMMENT 'FK(milestone_master)',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(300) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`milestone_file_id`),
  KEY `milestone_id` (`milestone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_milestone_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_milestone_master` (
  `milestone_id` int(11) NOT NULL AUTO_INCREMENT,
  `milestone_code` varchar(15) NOT NULL,
  `project_id` int(11) NOT NULL COMMENT 'FK(project_master)',
  `milestone_name` varchar(100) NOT NULL,
  `res_user` int(11) NOT NULL COMMENT 'FK(user_master)',
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Yes,0=No',
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`milestone_id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_milestone_task_trans`
--

CREATE TABLE IF NOT EXISTS `blzdsk_milestone_task_trans` (
  `milestone_task_id` int(11) NOT NULL AUTO_INCREMENT,
  `milestone_id` int(11) NOT NULL COMMENT 'FK(milestone_master)',
  `task_id` int(11) NOT NULL COMMENT 'FK(project_task_master)',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`milestone_task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_milestone_team_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_milestone_team_tran` (
  `miles_team_id` int(11) NOT NULL AUTO_INCREMENT,
  `milestone_id` int(11) NOT NULL COMMENT 'FK(milestone_master)',
  `user_id` int(11) NOT NULL COMMENT 'FK(user_master)',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`miles_team_id`),
  KEY `milestone_id` (`milestone_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_module_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_module_master` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `component_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `module_name` varchar(100) NOT NULL,
  `module_unique_name` varchar(100) NOT NULL,
  `controller_name` varchar(150) NOT NULL,
  `created_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=88 ;

--
-- Dumping data for table `blzdsk_module_master`
--

INSERT INTO `blzdsk_module_master` (`module_id`, `component_name`, `module_name`, `module_unique_name`, `controller_name`, `created_date`, `status`) VALUES
(7, 'User', 'User', 'User', 'User', '0000-00-00 00:00:00', 1),
(8, 'CRM', 'Opportunity', 'Opportunity', 'Opportunity', '2016-02-02 12:44:15', 1),
(9, 'CRM', 'Prospect', 'Prospect', 'Prospect', '2016-02-02 12:45:23', 1),
(11, 'CRM', 'Lead', 'Lead', 'Lead', '2016-02-02 12:49:39', 1),
(13, 'CRM', 'Task', 'Task', 'Task', '2016-02-02 12:50:06', 1),
(14, 'CRM', 'Campaign Group', 'Campaigngroup', 'Campaigngroup', '2016-02-02 12:53:07', 1),
(15, 'CRM', 'Contact', 'Contact', 'Contact', '2016-02-02 12:54:00', 1),
(16, 'PM', 'Costs', 'Costs', 'Costs', '2016-02-02 12:54:57', 1),
(17, 'settings', 'Role Master', 'Rolemaster', 'Rolemaster', '2016-02-02 12:55:15', 1),
(18, 'CRM', 'Request Budget', 'RequestBudget', 'RequestBudget', '2016-02-02 12:55:29', 1),
(19, 'CRM', 'Campaign Report', 'CampaignReport', 'CampaignReport', '2016-02-02 12:56:45', 1),
(21, 'CRM', 'Estimates', 'Estimates', 'Estimates', '2016-02-04 05:40:22', 1),
(23, 'CRM', 'Dashboard', 'Dashboard', 'Dashboard', '2016-02-04 05:44:48', 1),
(24, 'PM', 'Home', 'Home', 'Home', '2016-02-04 05:45:20', 1),
(25, 'PM', 'Milestone', 'Milestone', 'Milestone', '2016-02-04 06:30:46', 1),
(26, 'PM', 'Project Management', 'Projectmanagement', 'Projectmanagement', '2016-02-04 06:30:56', 1),
(27, 'PM', 'Project Task', 'ProjectTask', 'ProjectTask', '2016-02-04 06:31:04', 1),
(28, 'settings', 'File Manager', 'Filemanager', 'Filemanager', '2016-02-04 06:31:18', 1),
(33, 'CRM', 'Sales Overview', 'SalesOverview', 'SalesOverview', '2016-02-09 12:34:52', 1),
(34, 'CRM', 'Email Template', 'Emailtemplate', 'Emailtemplate', '2016-02-09 15:00:23', 1),
(35, 'CRM', 'Product', 'Product', 'Product', '2016-02-12 05:54:05', 1),
(36, 'PM', 'Activities', 'Activities', 'Activities', '2016-02-16 12:37:18', 1),
(38, 'CRM', 'Product Group', 'ProductGroup', 'ProductGroup', '2016-02-17 11:49:27', 1),
(39, 'PM', 'Timesheets', 'Timesheets', 'Timesheets', '2016-02-17 12:31:51', 1),
(40, 'settings', 'Currency Settings', 'Currencysettings', 'Currencysettings', '2016-02-18 11:51:11', 1),
(41, 'PM', 'Messages', 'Messages', 'Messages', '2016-02-19 08:47:16', 1),
(43, 'CRM', 'Marketing Campaign', 'Marketingcampaign', 'Marketingcampaign', '2016-02-19 10:13:14', 1),
(44, 'CRM', 'Manage Campaigns', 'ManageCampaigns', 'ManageCampaigns', '2016-02-19 10:13:43', 1),
(45, 'CRM', 'Account', 'Account', 'Account', '2016-02-22 04:24:57', 1),
(46, 'PM', 'Project Dashboard', 'Projectdashboard', 'Projectdashboard', '2016-02-23 10:51:47', 1),
(47, 'CRM', 'Campaign Archive', 'Campaignarchive', 'Campaignarchive', '2016-02-24 09:43:38', 1),
(49, 'settings', 'Settings', 'Settings', 'Settings', '2016-03-01 06:41:36', 1),
(50, 'settings', 'Project Status', 'ProjectStatus', 'ProjectStatus', '2016-03-01 13:08:12', 1),
(51, 'Support', 'Support', 'Support', 'Support', '2016-03-01 14:26:25', 1),
(52, 'Support', 'Ticket', 'Ticket', 'Ticket', '2016-03-01 14:27:49', 1),
(53, 'PM', 'Project Incidents', 'ProjectIncidents', 'ProjectIncidents', '2016-03-03 12:25:47', 1),
(54, 'PM', 'TeamMembers', 'TeamMembers', 'TeamMembers', '2016-02-08 09:03:19', 1),
(55, 'Support', 'Knowledge Base', 'KnowledgeBase', 'KnowledgeBase', '2016-03-04 10:04:37', 1),
(56, 'Support', 'Company', 'Company', 'Company', '2016-03-07 14:04:55', 1),
(57, 'Support', 'Support Settings', 'SupportSettings', 'SupportSettings', '2016-03-09 04:23:54', 1),
(58, 'Support', 'Support Team', 'SupportTeam', 'SupportTeam', '2016-03-09 10:22:58', 1),
(59, 'PM', 'Project Incidents Type', 'ProjectIncidentsType', 'ProjectIncidentsType', '2016-03-09 14:23:44', 1),
(61, 'CRM', 'Estimate Settings', 'EstimateSettings', 'EstimateSettings', '2016-03-14 10:09:30', 1),
(65, 'CRM', 'Estimates Client', 'EstimatesClient', 'EstimatesClient', '2016-03-22 13:01:34', 1),
(66, 'PM', 'Invoices', 'Invoices', 'Invoices', '2016-03-23 10:22:09', 1),
(67, 'Support', 'Support Report', 'SupportReport', 'SupportReport', '2016-03-30 05:49:40', 1),
(68, 'settings', 'Sales Target Settings', 'SalesTargetSettings', 'SalesTargetSettings', '2016-04-01 13:59:49', 1),
(71, 'CRM', 'Signature', 'Signature', 'Signature', '2016-04-11 07:25:36', 1),
(72, 'CRM', 'Supplier', 'Supplier', 'Supplier', '2016-04-11 07:25:36', 1),
(75, 'CRM', 'Cases Type', 'CasesType', 'CasesType', '2016-04-11 07:25:36', 1),
(77, 'CRM', 'Meeting', 'Meeting', 'Meeting', '2016-04-11 07:25:36', 1),
(78, 'CRM', 'Message', 'Message', 'Message', '2016-04-11 07:25:36', 1),
(79, 'Support', 'Support Contact', 'SupportContact', 'SupportContact', '2016-04-11 07:25:36', 1),
(80, 'CRM', 'ArchiveCampaign', 'ArchiveCampaign', 'ArchiveCampaign', '2016-04-11 07:25:36', 1),
(81, 'Support', 'SupportTask', 'SupportTask', 'SupportTask', '2016-04-11 07:25:36', 1),
(86, 'CRM', 'CrmCompany', 'CrmCompany', 'CrmCompany', '2016-04-11 07:25:36', 1),
(87, 'CRM', 'GetApiData', 'GetApiData', 'GetApiData', '2016-04-11 07:25:36', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_newsletter_lists_contact`
--

CREATE TABLE IF NOT EXISTS `blzdsk_newsletter_lists_contact` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_id` int(11) NOT NULL COMMENT 'Contact id from Contact master',
  `list_id` text NOT NULL,
  `list_type` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_newsletter_lists_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_newsletter_lists_master` (
  `newsletter_id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL,
  `lists_id` text NOT NULL,
  `lists_name` text NOT NULL,
  `lists_type` int(11) NOT NULL COMMENT '1-Mailchimp, 2-Campaign Mointor, 3- Moosend, 4- Getresponse',
  `created_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `status` int(11) NOT NULL COMMENT '0-inactive, 1- Active',
  PRIMARY KEY (`newsletter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_notes`
--

CREATE TABLE IF NOT EXISTS `blzdsk_notes` (
  `note_id` int(11) NOT NULL AUTO_INCREMENT,
  `notes_related_id` int(11) NOT NULL,
  `note_subject` varchar(300) NOT NULL,
  `note_description` text NOT NULL,
  `note_status` int(11) NOT NULL COMMENT '1- contact, 2- account, 3 - Lead, 4- Opportunity ',
  `created_by` int(11) NOT NULL,
  `add_to_communication` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0.No 1.Yes',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`note_id`),
  KEY `contact_id` (`notes_related_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_opportunity_requirement`
--

CREATE TABLE IF NOT EXISTS `blzdsk_opportunity_requirement` (
  `requirement_id` int(11) NOT NULL AUTO_INCREMENT,
  `requirement_description` longtext NOT NULL,
  `prospect_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0.active 1.inactive',
  PRIMARY KEY (`requirement_id`),
  KEY `prospect_id` (`prospect_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_opportunity_requirement_contacts`
--

CREATE TABLE IF NOT EXISTS `blzdsk_opportunity_requirement_contacts` (
  `requirement_contacts_id` int(11) NOT NULL AUTO_INCREMENT,
  `requirement_id` int(11) NOT NULL,
  `primary_contact` tinyint(11) NOT NULL COMMENT '1.selected',
  `prospect_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`requirement_contacts_id`),
  KEY `requirement_id` (`requirement_id`),
  KEY `prospect_id` (`prospect_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_product_group_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_product_group_master` (
  `product_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_group_name` varchar(30) NOT NULL,
  `product_group_description` text NOT NULL,
  `product_group_total_amt` float(12,2) NOT NULL,
  `product_group_discounted_amt` float(12,2) NOT NULL,
  `product_group_tax_amt` float(12,2) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` enum('0','1') NOT NULL COMMENT '1-active, 0-inactive',
  `is_delete` enum('0','1') NOT NULL COMMENT '1-yes, 0-no',
  PRIMARY KEY (`product_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_product_group_relation`
--

CREATE TABLE IF NOT EXISTS `blzdsk_product_group_relation` (
  `product_group_rel_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `product_group_id` int(11) NOT NULL,
  `product_discount` float(12,2) NOT NULL,
  `discount_option` varchar(11) NOT NULL,
  `product_qty` int(11) NOT NULL,
  `product_total` float(12,2) NOT NULL COMMENT 'product wise total amount with discount',
  `product_tax_id` int(11) NOT NULL,
  `product_group_status` enum('0','1') NOT NULL COMMENT '1-essential, 0-accessories',
  `is_delete` enum('0','1') NOT NULL COMMENT '1-yes, 0-no',
  PRIMARY KEY (`product_group_rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_product_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_product_master` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) NOT NULL,
  `product_type` varchar(100) NOT NULL,
  `product_description` text NOT NULL,
  `purchase_price_unit` decimal(12,2) NOT NULL,
  `sales_price_unit` decimal(12,2) NOT NULL,
  `product_group_status` tinyint(1) NOT NULL DEFAULT '0',
  `gross_margin` decimal(12,2) NOT NULL,
  `product_tax_id` int(11) NOT NULL,
  `currency_symbol` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` int(11) NOT NULL COMMENT '1-active,0-inactive',
  `is_delete` enum('0','1') NOT NULL COMMENT '1-yes, 0-no',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_product_tax_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_product_tax_master` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(255) NOT NULL,
  `tax_percentage` float(10,2) NOT NULL,
  `is_delete` tinyint(1) DEFAULT '0' COMMENT '1=Yes,0=No',
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_activities`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_activities` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `project_id` int(11) NOT NULL,
  `status_id` tinyint(4) NOT NULL DEFAULT '0',
  `activity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activity_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_assign_trans`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_assign_trans` (
  `project_assign_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL COMMENT 'FK(project_master)',
  `user_id` int(11) NOT NULL COMMENT 'FK(user_master)',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`project_assign_id`),
  KEY `project_id` (`project_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_incidents`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_incidents` (
  `incident_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `type_id` varchar(50) NOT NULL COMMENT 'Fk-project incidents type',
  `project_incidents_related_id` int(11) NOT NULL,
  `project_incidents_status` int(11) NOT NULL,
  `business_cases` varchar(500) DEFAULT NULL,
  `business_subject` varchar(250) DEFAULT NULL,
  `responsible` int(11) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `incident_status` int(11) DEFAULT NULL,
  `description` text,
  `file` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Yes,0=No',
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`incident_id`),
  KEY `project_id` (`project_id`,`created_by`,`modified_by`),
  KEY `created_by` (`created_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_incidents_files`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_incidents_files` (
  `incident_file_id` int(11) NOT NULL AUTO_INCREMENT,
  `incident_id` int(11) NOT NULL COMMENT 'FK(project_incident_master)',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(300) NOT NULL,
  `upload_status` tinyint(1) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`incident_file_id`),
  KEY `incident_id` (`incident_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_incidents_type`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_incidents_type` (
  `incident_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `incident_type_name` varchar(100) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Yes,0=No',
  `status` tinyint(1) NOT NULL COMMENT '1-active,0-deactive',
  PRIMARY KEY (`incident_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_invoices`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_invoices` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_code` varchar(10) NOT NULL,
  `project_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `amount` float NOT NULL,
  `client_id` int(11) NOT NULL,
  `not_associat_project_id` int(11) NOT NULL DEFAULT '0',
  `show_in_client_area` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1-Yes,0-No',
  `auto_send` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1- Send.0-Not send',
  `recurring` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1- Send.0-Not send',
  `recurring_time` varchar(10) NOT NULL,
  `currency` int(11) NOT NULL,
  `notes` text NOT NULL,
  `total_payment` float NOT NULL,
  `send_invoice_client` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1-Yes,0-No',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `is_delete` tinyint(4) NOT NULL COMMENT '1- delete .0-Not delete',
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_invoices_files`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_invoices_files` (
  `invoice_file_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL COMMENT 'FK(project_invoice)',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(300) NOT NULL,
  `size` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`invoice_file_id`),
  KEY `milestone_id` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_invoices_items`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_invoices_items` (
  `invoice_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `qty_hours` float NOT NULL,
  `rate` float NOT NULL,
  `tax_rate` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `discount` float NOT NULL,
  `cost` float NOT NULL,
  PRIMARY KEY (`invoice_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_invoices_payment`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_invoices_payment` (
  `invoice_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL COMMENT 'From invoice',
  `amount` float NOT NULL,
  `amount_per` int(10) NOT NULL,
  `due_on` date NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`invoice_payment_id`),
  KEY `invoice_id` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_invoice_clients`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_invoice_clients` (
  `invoice_client_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `prospect_id` int(11) NOT NULL COMMENT 'prospect_id as a client',
  `client_type` varchar(11) NOT NULL,
  `client_name` varchar(25) DEFAULT NULL,
  `recipient_id` int(11) NOT NULL,
  `recipient_type` varchar(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`invoice_client_id`),
  KEY `estimate_id` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_invoice_send`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_invoice_send` (
  `invoice_send_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `recipient_type` varchar(11) NOT NULL,
  `invoice_open_onetime_status` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1- Active, 0 - Inactive',
  `created_date` datetime NOT NULL,
  `invoice_send_status` tinyint(4) NOT NULL COMMENT '0 - Inactive, 1 - Active',
  PRIMARY KEY (`invoice_send_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_master` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_code` varchar(20) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_desc` text NOT NULL,
  `project_budget` int(11) NOT NULL,
  `client_id` int(11) NOT NULL COMMENT 'From prospect',
  `client_type` varchar(10) NOT NULL,
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `project_icon` varchar(200) NOT NULL,
  `icon_path` varchar(200) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Yes,0=No',
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`project_id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_message`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `time` int(11) NOT NULL,
  `project_id` int(11) NOT NULL COMMENT 'FK(project_master)',
  `user_id` int(11) NOT NULL COMMENT 'FK(login)',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `project_id` (`project_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_projectmanager_assign`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_projectmanager_assign` (
  `unique_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`unique_id`),
  KEY `project_id` (`project_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_sales_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_sales_master` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `project_auto_id` varchar(20) NOT NULL,
  `project_name` varchar(50) NOT NULL,
  `deal_id` int(11) NOT NULL COMMENT 'FK(deal_sales)',
  `value` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `progress` int(3) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`project_id`),
  KEY `prospect_id` (`prospect_id`,`deal_id`),
  KEY `deal_id` (`deal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_status`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(15) NOT NULL,
  `status_color` varchar(10) NOT NULL,
  `status_font_icon` varchar(30) NOT NULL,
  `default_status` tinyint(1) NOT NULL COMMENT '1-default',
  `status_order` tinyint(1) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `is_delete` tinyint(1) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `blzdsk_project_status`
--

INSERT INTO `blzdsk_project_status` (`status_id`, `status_name`, `status_color`, `status_font_icon`, `default_status`, `status_order`, `created_date`, `modified_date`, `created_by`, `modified_by`, `is_delete`) VALUES
(1, 'Planned', '#8f66a9', 'calculator', 1, 1, '0000-00-00 00:00:00', '2016-03-22 05:33:45', 0, 0, 0),
(2, 'Open', '#87ceeb', 'tasks', 1, 2, '0000-00-00 00:00:00', '2016-03-01 13:50:44', 0, 0, 0),
(3, 'In Progress', '#ff9933', 'signal', 1, 3, '0000-00-00 00:00:00', '2016-03-22 08:56:31', 0, 0, 0),
(4, 'On Hold', '#5118cc', 'modx', 1, 4, '0000-00-00 00:00:00', '2016-03-15 14:38:28', 0, 0, 0),
(5, 'Completed', '#8be02e', 'check', 1, 5, '2016-03-12 16:11:53', '0000-00-00 00:00:00', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_task_files`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_task_files` (
  `task_file_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL COMMENT 'FK(task_master)',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(300) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`task_file_id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_task_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_task_master` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_code` varchar(15) NOT NULL,
  `milestone_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL COMMENT 'FK(project_master)',
  `sub_task_id` int(11) NOT NULL COMMENT 'FK(task_master)',
  `task_name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `in_project_scope` tinyint(1) NOT NULL COMMENT '1-yes,0-no',
  `notify_team` tinyint(1) NOT NULL COMMENT '1-yes,0-no',
  `notify_project_manager` tinyint(1) NOT NULL COMMENT '1-yes,0-no',
  `deal_id` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Yes,0=No',
  `status` tinyint(1) NOT NULL COMMENT '1-planed,2-open,3-in process,4-completed',
  PRIMARY KEY (`task_id`),
  KEY `project_id` (`project_id`),
  KEY `sub_task_id` (`sub_task_id`),
  KEY `milestone_id` (`milestone_id`),
  KEY `milestone_id_2` (`milestone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_task_team_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_task_team_tran` (
  `task_trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL COMMENT 'FK(project_task_master)',
  `user_id` int(11) NOT NULL COMMENT 'FK(user_master)',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`task_trans_id`),
  KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_team_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_team_master` (
  `team_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `team_name` varchar(150) NOT NULL,
  `project_id` bigint(20) NOT NULL,
  `team_lead_id` bigint(20) NOT NULL,
  `notify_members` tinyint(4) DEFAULT NULL COMMENT '0=false,1=true',
  `schedule_meeting` datetime DEFAULT NULL COMMENT '0=false,1=true',
  `status` tinyint(1) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) NOT NULL,
  `is_delete` tinyint(1) DEFAULT '0' COMMENT '1=Yes,0=No',
  `created_ip` varchar(25) NOT NULL,
  `updated_ip` int(25) NOT NULL,
  PRIMARY KEY (`team_id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_team_members`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_team_members` (
  `team_member_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `team_id` bigint(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  `project_id` bigint(20) NOT NULL,
  `notify_tl` tinyint(1) DEFAULT NULL COMMENT '1=Yes,0=No',
  `notify_member` tinyint(1) DEFAULT NULL COMMENT '1=Yes,0=No',
  `schedule_meeting` datetime DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `reminder` tinyint(1) DEFAULT '0' COMMENT '1=Yes,0=No',
  `before_after` tinyint(1) DEFAULT NULL COMMENT '0=before,1=after',
  `remind_time` varchar(50) DEFAULT NULL,
  `repeat` varchar(50) DEFAULT NULL,
  `remind_day` varchar(50) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Yes,0=No',
  `status` tinyint(1) DEFAULT NULL COMMENT '1=Active,2-Inactive',
  PRIMARY KEY (`team_member_id`),
  KEY `member_id` (`member_id`),
  KEY `project_id` (`project_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_project_timesheets`
--

CREATE TABLE IF NOT EXISTS `blzdsk_project_timesheets` (
  `timesheet_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `estimate_time` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `spent_time` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `timer_start_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Started,0=Not Yet',
  `timer_end_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Started,0=Not Yet',
  `timer_pause_flag` tinyint(1) NOT NULL,
  `timer_restart_timestamp` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `timer_pause_timestamp` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `timer_start_timestamp` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `timer_end_timestamp` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `pause_time` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `user_id` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Yes,0=No',
  PRIMARY KEY (`timesheet_id`),
  KEY `project_id` (`project_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_prospect_contacts_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_prospect_contacts_tran` (
  `pro_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `contact_name` varchar(30) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `phone_no` varchar(12) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`pro_contact_id`),
  KEY `prospect_id` (`prospect_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_prospect_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_prospect_master` (
  `prospect_id` int(11) NOT NULL AUTO_INCREMENT,
  `duplicate_opportunity_id` int(11) DEFAULT NULL,
  `is_merge` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0.No 1.Yes',
  `merge_with` int(11) NOT NULL,
  `prospect_assign` int(11) NOT NULL,
  `prospect_related_id` int(11) NOT NULL,
  `deal_status` tinyint(4) DEFAULT '0' COMMENT '1. Contact 2. Account 3. Lead 4. Opporutnity',
  `prospect_auto_id` varchar(20) NOT NULL,
  `prospect_name` varchar(50) NOT NULL,
  `status_type` tinyint(4) NOT NULL COMMENT '1-prospect,2-Company,3-client,4- Lost Client',
  `company_id` int(11) NOT NULL,
  `address1` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `creation_date` date NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country_id` int(11) NOT NULL,
  `number_type1` int(11) NOT NULL COMMENT '1.home 2.mobile 3.office',
  `phone_no` varchar(50) NOT NULL,
  `number_type2` int(11) NOT NULL,
  `phone_no2` varchar(20) NOT NULL,
  `prospect_owner_id` int(11) NOT NULL,
  `language_id` int(11) DEFAULT NULL,
  `branch_id` int(11) NOT NULL COMMENT 'FK(branch_master)',
  `estimate_prospect_worth` varchar(20) NOT NULL,
  `prospect_generate` tinyint(4) NOT NULL,
  `campaign_id` int(11) NOT NULL COMMENT 'FK(campaign)',
  `description` text NOT NULL,
  `file` varchar(100) NOT NULL,
  `fb` varchar(250) DEFAULT NULL,
  `twitter` varchar(250) DEFAULT NULL,
  `linkedin` varchar(250) DEFAULT NULL,
  `credit_limit` float(10,2) DEFAULT NULL,
  `contact_date` date NOT NULL,
  `is_delete` tinyint(4) NOT NULL COMMENT '0.No 1.Yes',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_estimate_sent` tinyint(4) DEFAULT '0',
  `won_lost_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`prospect_id`),
  KEY `prospect_owner_id` (`prospect_owner_id`),
  KEY `branch_id` (`branch_id`),
  KEY `campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_prospect_products_tran`
--

CREATE TABLE IF NOT EXISTS `blzdsk_prospect_products_tran` (
  `pro_product_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`pro_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_request_budget_files_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_request_budget_files_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `budget_campaign_id` int(11) NOT NULL COMMENT 'campaign master id',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  KEY `campaign_id` (`budget_campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_role_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_role_master` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  `is_delete` int(4) NOT NULL DEFAULT '0',
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `blzdsk_role_master`
--

INSERT INTO `blzdsk_role_master` (`role_id`, `role_name`, `created_date`, `status`, `is_delete`, `updated_by`) VALUES
(39, 'SuperAdmin', '2016-02-02 12:59:21', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_sales_target_settings`
--

CREATE TABLE IF NOT EXISTS `blzdsk_sales_target_settings` (
  `target_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `currency_symbol` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `month` varchar(100) NOT NULL,
  `target` bigint(15) NOT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_salutions_list`
--

CREATE TABLE IF NOT EXISTS `blzdsk_salutions_list` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_name` varchar(10) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0-disable,1- enabled',
  `created_date` date NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `blzdsk_salutions_list`
--

INSERT INTO `blzdsk_salutions_list` (`s_id`, `s_name`, `status`, `created_date`) VALUES
(1, 'Mr.', 1, '2016-03-04'),
(2, 'Mrs.', 1, '2016-03-04'),
(3, 'Miss.', 1, '2016-03-04'),
(4, 'Dr.', 1, '2016-03-04'),
(5, 'Prof.', 1, '2016-03-04');

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_sampletable`
--

CREATE TABLE IF NOT EXISTS `blzdsk_sampletable` (
  `smp_id` int(15) NOT NULL AUTO_INCREMENT,
  `sample_name` varchar(50) NOT NULL,
  `sample_status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`smp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_schedule_meeting`
--

CREATE TABLE IF NOT EXISTS `blzdsk_schedule_meeting` (
  `meeting_id` int(11) NOT NULL AUTO_INCREMENT,
  `meeting_master_id` int(11) NOT NULL,
  `meet_related_id` int(11) NOT NULL,
  `meet_status` tinyint(4) NOT NULL COMMENT '1. Contact 2. Account 3. Lead 4. Opporutnity',
  `meet_user_id` int(11) NOT NULL COMMENT 'From Login Table',
  `meet_contact_id` int(11) NOT NULL COMMENT 'From Contact Master',
  `is_delete` int(11) NOT NULL COMMENT '0 - No, 1 -Yes',
  `created_date` date NOT NULL,
  PRIMARY KEY (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_schedule_meeting_files_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_schedule_meeting_files_master` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `meeting_master_id` int(11) NOT NULL COMMENT 'meeting master id',
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `upload_status` tinyint(4) NOT NULL COMMENT '0-browse,1-from blazedesk library',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_schedule_meeting_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_schedule_meeting_master` (
  `meeting_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `meet_user_id` int(11) NOT NULL,
  `meet_title` text NOT NULL,
  `meeting_description` text,
  `additiona_receipent_email` text,
  `meeting_date` date DEFAULT NULL,
  `meeting_time` time DEFAULT NULL,
  `meeting_end_time` time NOT NULL,
  `meeting_reminder` int(11) NOT NULL,
  `reminder_date` date NOT NULL,
  `reminder_time` time NOT NULL,
  `meeting_location` text NOT NULL,
  `company_id_location` int(11) DEFAULT NULL COMMENT 'company location if meeting location is company',
  `is_another_location` int(11) NOT NULL COMMENT 'if Another Location is Enterred',
  `is_private` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `is_public` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `is_event` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `is_recurring` int(11) NOT NULL COMMENT '0.No 1.Yes',
  `recurring_repeat` varchar(10) NOT NULL,
  `recurring_end_date` date NOT NULL,
  `is_delete` int(11) NOT NULL COMMENT '0-no, 1 yes',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`meeting_master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_schedule_meeting_receipents`
--

CREATE TABLE IF NOT EXISTS `blzdsk_schedule_meeting_receipents` (
  `receipents_id` int(11) NOT NULL AUTO_INCREMENT,
  `meeting_master_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_type` int(11) NOT NULL COMMENT ' 1-Employee, 2- contact, 3 - Company,4-Opporutnity, 5-Lead, 6- Account',
  `is_delete` int(11) NOT NULL COMMENT '0-No , 1 Yes',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`receipents_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_supplier_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_supplier_master` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  `is_delete` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_support_priority`
--

CREATE TABLE IF NOT EXISTS `blzdsk_support_priority` (
  `support_priority_id` int(11) NOT NULL AUTO_INCREMENT,
  `support_type_id` int(11) NOT NULL,
  `priority` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`support_priority_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `blzdsk_support_priority`
--

INSERT INTO `blzdsk_support_priority` (`support_priority_id`, `support_type_id`, `priority`, `status`, `is_delete`) VALUES
(1, 0, 'Low', 1, 0),
(2, 0, 'Medium', 1, 0),
(3, 0, 'High', 1, 0),
(4, 0, 'Immediate ', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_support_sales_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_support_sales_master` (
  `support_id` int(11) NOT NULL AUTO_INCREMENT,
  `prospect_id` int(11) NOT NULL COMMENT 'FK(prospect_master)',
  `ticket_id` varchar(20) NOT NULL,
  `product_id` int(11) NOT NULL COMMENT 'FK(product_master)',
  `subject` varchar(100) NOT NULL,
  `days_open` int(3) NOT NULL,
  `creation_date` date NOT NULL,
  `due_date` date NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`support_id`),
  KEY `prospect_id` (`prospect_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_support_settings`
--

CREATE TABLE IF NOT EXISTS `blzdsk_support_settings` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `priority` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_support_status`
--

CREATE TABLE IF NOT EXISTS `blzdsk_support_status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(15) NOT NULL,
  `status_color` varchar(10) NOT NULL,
  `status_font_icon` varchar(30) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `blzdsk_support_status`
--

INSERT INTO `blzdsk_support_status` (`status_id`, `status_name`, `status_color`, `status_font_icon`, `created_date`, `modified_date`, `is_delete`) VALUES
(1, 'New', '#CE362A', 'tags', '2016-03-10 12:33:43', '0000-00-00 00:00:00', 0),
(2, 'In Progress', '#18BE5F', 'signal', '2016-03-10 13:17:54', '0000-00-00 00:00:00', 0),
(3, 'On Hold', '#FF5400', 'signal', '2016-03-10 13:22:52', '0000-00-00 00:00:00', 0),
(4, 'Completed', '#3E90D3', 'check', '2016-03-10 13:24:47', '0000-00-00 00:00:00', 0),
(5, 'Assigned', '#20BE5F', 'tags', '2016-03-10 13:54:11', '2016-03-10 13:55:22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_support_task_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_support_task_master` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_assign` int(11) NOT NULL,
  `task_related_id` int(11) NOT NULL DEFAULT '0',
  `task_status` tinyint(4) NOT NULL COMMENT '1. Contact 2. Account 3. Lead 4. Opporutnity',
  `task_name` varchar(30) NOT NULL,
  `importance` varchar(20) NOT NULL,
  `remember` tinyint(4) NOT NULL,
  `reminder_date` date NOT NULL,
  `reminder_time` time NOT NULL,
  `task_description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_delete` tinyint(4) NOT NULL COMMENT '0.No 1.Yes',
  `created_by` int(11) DEFAULT NULL,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_support_team_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_support_team_master` (
  `team_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `team_name` varchar(150) NOT NULL,
  `team_lead_id` bigint(20) NOT NULL,
  `notify_members` tinyint(4) DEFAULT NULL COMMENT '0=false,1=true',
  `schedule_meeting` datetime DEFAULT NULL COMMENT '0=false,1=true',
  `status` tinyint(1) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) NOT NULL,
  `created_ip` varchar(25) NOT NULL,
  `updated_ip` int(25) NOT NULL,
  `is_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_support_team_members`
--

CREATE TABLE IF NOT EXISTS `blzdsk_support_team_members` (
  `team_member_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `team_id` bigint(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  `notify_tl` tinyint(1) DEFAULT NULL COMMENT '1=Yes,0=No',
  `notify_member` tinyint(1) DEFAULT NULL COMMENT '1=Yes,0=No',
  `schedule_meeting` datetime DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `reminder` tinyint(1) DEFAULT '0' COMMENT '1=Yes,0=No',
  `before_after` tinyint(1) DEFAULT NULL COMMENT '0=before,1=after',
  `remind_time` varchar(50) NOT NULL,
  `repeat` varchar(50) NOT NULL,
  `remind_day` varchar(50) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '1=Active,2-Inactive',
  `is_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`team_member_id`),
  KEY `member_id` (`member_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_support_type`
--

CREATE TABLE IF NOT EXISTS `blzdsk_support_type` (
  `support_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`support_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `blzdsk_support_type`
--

INSERT INTO `blzdsk_support_type` (`support_type_id`, `type`, `status`, `is_delete`) VALUES
(1, 'Immediate', 1, 1),
(2, 'High', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_task_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_task_master` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_assign` int(11) NOT NULL,
  `task_related_id` int(11) NOT NULL DEFAULT '0',
  `task_status` tinyint(4) NOT NULL COMMENT '1. Contact 2. Account 3. Lead 4. Opporutnity',
  `task_name` varchar(30) NOT NULL,
  `importance` varchar(20) NOT NULL,
  `remember` tinyint(4) NOT NULL,
  `reminder_date` date NOT NULL,
  `before_status` tinyint(4) NOT NULL,
  `repeat` varchar(10) NOT NULL,
  `reminder_time` time NOT NULL,
  `remind_before_min` varchar(30) NOT NULL,
  `task_description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_delete` tinyint(4) NOT NULL COMMENT '0.No 1.Yes',
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_telemarketing_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_telemarketing_master` (
  `tele_id` int(15) NOT NULL AUTO_INCREMENT,
  `tele_name` varchar(155) NOT NULL,
  `company_name` varchar(155) NOT NULL,
  `phone_no` varchar(100) NOT NULL,
  `remark` longtext NOT NULL,
  `status` int(5) NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL,
  `user_id` int(5) NOT NULL,
  PRIMARY KEY (`tele_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_ticket_activity`
--

CREATE TABLE IF NOT EXISTS `blzdsk_ticket_activity` (
  `activity_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `ticket_id` int(10) NOT NULL,
  `activity` varchar(255) NOT NULL,
  `activity_date` datetime NOT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_ticket_contact`
--

CREATE TABLE IF NOT EXISTS `blzdsk_ticket_contact` (
  `ticket_contact_id` int(5) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(5) NOT NULL,
  `contact_id` int(5) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`ticket_contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_ticket_master`
--

CREATE TABLE IF NOT EXISTS `blzdsk_ticket_master` (
  `ticket_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `client_id` int(10) NOT NULL,
  `contact_id` varchar(115) NOT NULL,
  `ticket_subject` varchar(255) NOT NULL,
  `product_id` int(10) NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `due_date` date NOT NULL,
  `priority` varchar(100) NOT NULL,
  `ticket_desc` longtext NOT NULL,
  `suport_team` varchar(100) NOT NULL,
  `support_user` varchar(115) NOT NULL,
  `email_notification` tinyint(1) NOT NULL,
  `agent_notify` tinyint(1) NOT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_ticket_support_user`
--

CREATE TABLE IF NOT EXISTS `blzdsk_ticket_support_user` (
  `support_user_id` int(5) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(5) NOT NULL,
  `support_user` int(5) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`support_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_twitter_monthly_count`
--

CREATE TABLE IF NOT EXISTS `blzdsk_twitter_monthly_count` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `followers_count` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blzdsk_user_rights_trans`
--

CREATE TABLE IF NOT EXISTS `blzdsk_user_rights_trans` (
  `user_right_id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL COMMENT 'FK(module_master)',
  `login_id` int(11) NOT NULL COMMENT 'FK(login)',
  `created_date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '1-active,0-inactive',
  PRIMARY KEY (`user_right_id`),
  KEY `module_id` (`module_id`),
  KEY `login_id` (`login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blzdsk_appointment_master`
--
ALTER TABLE `blzdsk_appointment_master`
  ADD CONSTRAINT `blzdsk_appointment_master_ibfk_1` FOREIGN KEY (`contact_id`) REFERENCES `blzdsk_contact_master` (`contact_id`);

--
-- Constraints for table `blzdsk_budget_campaign_master`
--
ALTER TABLE `blzdsk_budget_campaign_master`
  ADD CONSTRAINT `blzdsk_budget_campaign_master_ibfk_1` FOREIGN KEY (`campaign_type_id`) REFERENCES `blzdsk_campaign_type_master` (`camp_type_id`),
  ADD CONSTRAINT `blzdsk_budget_campaign_master_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `blzdsk_supplier_master` (`supplier_id`);

--
-- Constraints for table `blzdsk_chat_master`
--
ALTER TABLE `blzdsk_chat_master`
  ADD CONSTRAINT `blzdsk_chat_master_ibfk_1` FOREIGN KEY (`contact1`) REFERENCES `blzdsk_contact_master` (`contact_id`),
  ADD CONSTRAINT `blzdsk_chat_master_ibfk_2` FOREIGN KEY (`contact2`) REFERENCES `blzdsk_contact_master` (`contact_id`);

--
-- Constraints for table `blzdsk_chat_tran`
--
ALTER TABLE `blzdsk_chat_tran`
  ADD CONSTRAINT `blzdsk_chat_tran_ibfk_1` FOREIGN KEY (`chat_id`) REFERENCES `blzdsk_chat_master` (`chat_id`);

--
-- Constraints for table `blzdsk_communication_contact_tran`
--
ALTER TABLE `blzdsk_communication_contact_tran`
  ADD CONSTRAINT `blzdsk_communication_contact_tran_ibfk_1` FOREIGN KEY (`comm_id`) REFERENCES `blzdsk_communication_sales` (`comm_id`),
  ADD CONSTRAINT `blzdsk_communication_contact_tran_ibfk_2` FOREIGN KEY (`contact_id`) REFERENCES `blzdsk_contact_master` (`contact_id`);

--
-- Constraints for table `blzdsk_communication_sales`
--
ALTER TABLE `blzdsk_communication_sales`
  ADD CONSTRAINT `blzdsk_communication_sales_ibfk_1` FOREIGN KEY (`prospect_id`) REFERENCES `blzdsk_prospect_master` (`prospect_id`),
  ADD CONSTRAINT `blzdsk_communication_sales_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `blzdsk_contact_master` (`contact_id`);

--
-- Constraints for table `blzdsk_company_master`
--
ALTER TABLE `blzdsk_company_master`
  ADD CONSTRAINT `blzdsk_company_master_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `blzdsk_branch_master` (`branch_id`);

--
-- Constraints for table `blzdsk_contarct_sales_master`
--
ALTER TABLE `blzdsk_contarct_sales_master`
  ADD CONSTRAINT `blzdsk_contarct_sales_master_ibfk_1` FOREIGN KEY (`prospect_id`) REFERENCES `blzdsk_prospect_master` (`prospect_id`);

--
-- Constraints for table `blzdsk_cost_files`
--
ALTER TABLE `blzdsk_cost_files`
  ADD CONSTRAINT `blzdsk_cost_files_ibfk_1` FOREIGN KEY (`cost_id`) REFERENCES `blzdsk_cost_master` (`cost_id`);

--
-- Constraints for table `blzdsk_deal_master`
--
ALTER TABLE `blzdsk_deal_master`
  ADD CONSTRAINT `blzdsk_deal_master_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `blzdsk_contact_master` (`contact_id`),
  ADD CONSTRAINT `blzdsk_deal_master_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `blzdsk_company_master` (`company_id`),
  ADD CONSTRAINT `blzdsk_deal_master_ibfk_3` FOREIGN KEY (`contact_id`) REFERENCES `blzdsk_contact_master` (`contact_id`);

--
-- Constraints for table `blzdsk_deal_sales`
--
ALTER TABLE `blzdsk_deal_sales`
  ADD CONSTRAINT `blzdsk_deal_sales_ibfk_1` FOREIGN KEY (`prospect_id`) REFERENCES `blzdsk_prospect_master` (`prospect_id`);

--
-- Constraints for table `blzdsk_email_prospect_contact_tran`
--
ALTER TABLE `blzdsk_email_prospect_contact_tran`
  ADD CONSTRAINT `blzdsk_email_prospect_contact_tran_ibfk_1` FOREIGN KEY (`email_prospect_id`) REFERENCES `blzdsk_email_prospect` (`email_prospect_id`);

--
-- Constraints for table `blzdsk_estimate_prospect`
--
ALTER TABLE `blzdsk_estimate_prospect`
  ADD CONSTRAINT `blzdsk_estimate_prospect_ibfk_1` FOREIGN KEY (`responsible_emp_id`) REFERENCES `blzdsk_contact_master` (`contact_id`);

--
-- Constraints for table `blzdsk_estimate_prospect_contact_tran`
--
ALTER TABLE `blzdsk_estimate_prospect_contact_tran`
  ADD CONSTRAINT `blzdsk_estimate_prospect_contact_tran_ibfk_1` FOREIGN KEY (`estimate_prospect_id`) REFERENCES `blzdsk_estimate_prospect` (`estimate_prospect_id`);

--
-- Constraints for table `blzdsk_files_sales_master`
--
ALTER TABLE `blzdsk_files_sales_master`
  ADD CONSTRAINT `blzdsk_files_sales_master_ibfk_1` FOREIGN KEY (`prospect_id`) REFERENCES `blzdsk_prospect_master` (`prospect_id`);

--
-- Constraints for table `blzdsk_invoice_sales_master`
--
ALTER TABLE `blzdsk_invoice_sales_master`
  ADD CONSTRAINT `blzdsk_invoice_sales_master_ibfk_1` FOREIGN KEY (`prospect_id`) REFERENCES `blzdsk_prospect_master` (`prospect_id`),
  ADD CONSTRAINT `blzdsk_invoice_sales_master_ibfk_2` FOREIGN KEY (`deal_id`) REFERENCES `blzdsk_deal_master` (`deal_id`);

--
-- Constraints for table `blzdsk_milestone_files`
--
ALTER TABLE `blzdsk_milestone_files`
  ADD CONSTRAINT `blzdsk_milestone_files_ibfk_1` FOREIGN KEY (`milestone_id`) REFERENCES `blzdsk_milestone_master` (`milestone_id`);

--
-- Constraints for table `blzdsk_milestone_master`
--
ALTER TABLE `blzdsk_milestone_master`
  ADD CONSTRAINT `blzdsk_milestone_master_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `blzdsk_project_master` (`project_id`);

--
-- Constraints for table `blzdsk_milestone_team_tran`
--
ALTER TABLE `blzdsk_milestone_team_tran`
  ADD CONSTRAINT `blzdsk_milestone_team_tran_ibfk_1` FOREIGN KEY (`milestone_id`) REFERENCES `blzdsk_milestone_master` (`milestone_id`),
  ADD CONSTRAINT `blzdsk_milestone_team_tran_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `blzdsk_login` (`login_id`);

--
-- Constraints for table `blzdsk_project_assign_trans`
--
ALTER TABLE `blzdsk_project_assign_trans`
  ADD CONSTRAINT `blzdsk_project_assign_trans_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `blzdsk_project_master` (`project_id`),
  ADD CONSTRAINT `blzdsk_project_assign_trans_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `blzdsk_login` (`login_id`);

--
-- Constraints for table `blzdsk_project_incidents`
--
ALTER TABLE `blzdsk_project_incidents`
  ADD CONSTRAINT `blzdsk_project_incidents_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `blzdsk_project_master` (`project_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `blzdsk_project_message`
--
ALTER TABLE `blzdsk_project_message`
  ADD CONSTRAINT `blzdsk_project_message_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `blzdsk_project_master` (`project_id`),
  ADD CONSTRAINT `blzdsk_project_message_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `blzdsk_login` (`login_id`);

--
-- Constraints for table `blzdsk_project_sales_master`
--
ALTER TABLE `blzdsk_project_sales_master`
  ADD CONSTRAINT `blzdsk_project_sales_master_ibfk_1` FOREIGN KEY (`prospect_id`) REFERENCES `blzdsk_prospect_master` (`prospect_id`),
  ADD CONSTRAINT `blzdsk_project_sales_master_ibfk_2` FOREIGN KEY (`deal_id`) REFERENCES `blzdsk_deal_master` (`deal_id`);

--
-- Constraints for table `blzdsk_project_task_files`
--
ALTER TABLE `blzdsk_project_task_files`
  ADD CONSTRAINT `blzdsk_project_task_files_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `blzdsk_project_task_master` (`task_id`);

--
-- Constraints for table `blzdsk_project_task_team_tran`
--
ALTER TABLE `blzdsk_project_task_team_tran`
  ADD CONSTRAINT `blzdsk_project_task_team_tran_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `blzdsk_project_task_master` (`task_id`),
  ADD CONSTRAINT `blzdsk_project_task_team_tran_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `blzdsk_login` (`login_id`);

--
-- Constraints for table `blzdsk_project_timesheets`
--
ALTER TABLE `blzdsk_project_timesheets`
  ADD CONSTRAINT `blzdsk_timesheets_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `blzdsk_project_master` (`project_id`),
  ADD CONSTRAINT `blzdsk_timesheets_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `blzdsk_login` (`login_id`);

--
-- Constraints for table `blzdsk_prospect_contacts_tran`
--
ALTER TABLE `blzdsk_prospect_contacts_tran`
  ADD CONSTRAINT `blzdsk_prospect_contacts_tran_ibfk_1` FOREIGN KEY (`prospect_id`) REFERENCES `blzdsk_prospect_master` (`prospect_id`);

--
-- Constraints for table `blzdsk_prospect_master`
--
ALTER TABLE `blzdsk_prospect_master`
  ADD CONSTRAINT `blzdsk_prospect_master_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `blzdsk_branch_master` (`branch_id`);

--
-- Constraints for table `blzdsk_support_sales_master`
--
ALTER TABLE `blzdsk_support_sales_master`
  ADD CONSTRAINT `blzdsk_support_sales_master_ibfk_1` FOREIGN KEY (`prospect_id`) REFERENCES `blzdsk_prospect_master` (`prospect_id`),
  ADD CONSTRAINT `blzdsk_support_sales_master_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `blzdsk_product_master` (`product_id`);

--
-- Constraints for table `blzdsk_user_rights_trans`
--
ALTER TABLE `blzdsk_user_rights_trans`
  ADD CONSTRAINT `blzdsk_user_rights_trans_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `blzdsk_module_master` (`module_id`),
  ADD CONSTRAINT `blzdsk_user_rights_trans_ibfk_2` FOREIGN KEY (`login_id`) REFERENCES `blzdsk_login` (`login_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
